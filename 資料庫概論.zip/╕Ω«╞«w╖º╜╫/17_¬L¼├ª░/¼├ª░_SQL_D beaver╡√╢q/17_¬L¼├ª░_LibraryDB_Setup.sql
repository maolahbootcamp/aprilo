--📘 建立書籍資料表
CREATE TABLE Books (
    BookID INTEGER PRIMARY KEY AUTOINCREMENT,
    Title TEXT ,
    Author TEXT,
    Publisher TEXT,
    ISBN TEXT ,
    Category TEXT
);

-- 📚 插入 10 筆書籍資料
INSERT INTO Books (Title, Author, Publisher, ISBN, Category) VALUES
('SQL 入門教學', '林大明', '資料出版社', '9781234567011', '資料庫'),
('Python 程式設計', '李小華', '城市出版社', '9781234567012', '程式語言'),
('資料結構與演算法', '王明志', '知識出版社', '9781234567013', '計算機科學'),
('行銷學原理', '陳怡君', '商業周刊', '9781234567014', '行銷'),
('現代經濟學', '楊宗憲', '大眾出版社', '9781234567015', '經濟'),
('職場英文實用句型', '張立群', '語言世界', '9781234567016', '語言學習'),
('大數據概論', '呂子昂', '科技出版社', '9781234567017', '科技'),
('機器學習基礎', '賴淑芬', '新知出版社', '9781234567018', '人工智慧'),
('數位轉型實戰', '陳柏宏', '企業出版社', '9781234567019', '企業管理'),
('國際貿易實務', '曾慶陽', '經濟日報', '9781234567020', '國際商務');

select * from Books 

-- 👥 建立會員資料表
CREATE TABLE Members (
    MemberID INTEGER PRIMARY KEY AUTOINCREMENT,
    Name TEXT NOT NULL,
    Email TEXT UNIQUE,
    Phone TEXT,
    JoinDate DATE NOT NULL
);


-- 👤 插入 10 筆會員資料
INSERT INTO Members (Name, Email, Phone, JoinDate) VALUES
('王小明', 'ming@example.com', '0912345678', '2023-01-15'),
('李小美', 'mei@example.com', '0922123456', '2023-02-10'),
('張大華', 'hua@example.com', '0933555777', '2023-03-01'),
('林志玲', 'ling@example.com', '0988123456', '2023-03-15'),
('陳柏宇', 'bo@example.com', '0911123456', '2023-04-01'),
('黃文賢', 'wen@example.com', '0931234567', '2023-04-20'),
('賴欣怡', 'hsin@example.com', '0955123456', '2023-05-05'),
('謝政達', 'cheng@example.com', '0966987456', '2023-05-25'),
('周冠宇', 'kuan@example.com', '0977456123', '2023-06-10'),
('曾怡婷', 'ting@example.com', '0987456123', '2023-06-25'); 

select * from Members

-- 📖 建立書籍狀態與借閱紀錄表
CREATE TABLE BookStatus (
    StatusID INTEGER PRIMARY KEY AUTOINCREMENT,
    BookID INTEGER ,
    BorrowedBy INTEGER,
    BorrowDate DATE,
    DueDate DATE,
    ReturnDate DATE,
    IsAvailable INTEGER ,
    FOREIGN KEY (BookID) REFERENCES Books(BookID),
    FOREIGN KEY (BorrowedBy) REFERENCES Members(MemberID)
);
select * from  BookStatus

-- 🔖 為 Books 建立索引
--CREATE INDEX idx_books_title ON Books (Title);
--CREATE INDEX idx_books_isbn ON Books (ISBN);
--CREATE INDEX idx_books_category ON Books (Category);

--
-- 🔖 為 Members 建立索引
--CREATE INDEX idx_members_name ON Members (Name);
--CREATE INDEX idx_members_email ON Members (Email);
--CREATE INDEX idx_members_joindate ON Members (JoinDate);

 🔖 為 BookStatus 建立索引
--CREATE INDEX idx_status_bookid ON BookStatus (BookID);
--CREATE INDEX idx_status_borrowedby ON BookStatus (BorrowedBy);
--CREATE INDEX idx_status_borrowdate ON BookStatus (BorrowDate);
--CREATE INDEX idx_status_duedate ON BookStatus (DueDate);
--CREATE INDEX idx_status_return ON BookStatus (ReturnDate);
--CREATE INDEX idx_status_borrowedby_date ON BookStatus (BorrowedBy, BorrowDate);



-- 🔄 建立觸發器：借書時自動設定應還日期為借出日 + 14 天
--CREATE TRIGGER set_due_date
--AFTER INSERT ON BookStatus
--FOR EACH ROW
--WHEN NEW.BorrowDate IS NOT NULL AND NEW.DueDate IS NULL
--BEGIN
--    UPDATE BookStatus
--    SET DueDate = DATE(NEW.BorrowDate, '+14 days')
--    WHERE StatusID = NEW.StatusID;
--END;

--SELECT * from set_due_date


--📊 查詢每本書的借閱次數
SELECT 
    B.Title AS 書名,
    COUNT(S.StatusID) AS 借閱次數
FROM 
    Books B
LEFT JOIN 
    BookStatus S ON B.BookID = S.BookID
GROUP BY 
    B.BookID, B.Title
ORDER BY 
    借閱次數 DESC;



