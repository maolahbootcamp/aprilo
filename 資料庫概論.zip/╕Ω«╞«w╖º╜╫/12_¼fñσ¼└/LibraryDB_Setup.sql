/*CREATE TABLE Books (
    book_id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    author TEXT,
    isbn TEXT UNIQUE,
    totalcopies INTEGER NOT NULL,
    availablecopies INTEGER NOT NULL
);


SELECT * FROM Books;

INSERT INTO Books (title, author, isbn, totalcopies, availablecopies)
VALUES 
('活著', '余華', '9787506365437', 5, 5),
('1984', '喬治·奧威爾', '9780141036144', 3, 3),
('追風箏的孩子', '卡勒德·胡賽尼', '9780060814648', 8, 8),
('殺死一隻知更鳥', '哈珀·李', '9780061120084', 6, 6),
('百年孤寂', '加布里埃爾·賣阿爾克', '9780060883289', 4, 4),
('小王子', '安托萬·德·聖埃克蘇佩里', '9780156012195', 10, 10),
('平凡的世界', '路遙', '9787544242388', 7, 7),
('島上書店', '加布瑞·塞文', '9780735222347', 5, 5),
('天使與魔鬼', '丹·布朗', '9780743493468', 12, 12),
('哈利·波特與魔法石', 'J.K.羅琳', '9780747532743', 15, 15);
*/

/*CREATE TABLE Members (
    member_id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE,
    phone TEXT,
    joindate DATE DEFAULT (date('now'))
);

INSERT INTO Members (name, email, phone, joindate)
VALUES 
('王曉明', 'john.wang@example.com', '0912345678', '2025-04-11'),
('張美麗', 'jane.chang@example.com', '0987654321', '2025-04-10'),
('方可莉', 'alice.fang@example.com', '0932123456', '2025-04-09'),
('李大同', 'bob.lee@example.com', '0978112233', '2025-04-08'),
('陳奕安', 'charlie.chen@example.com', '0955667788', '2025-04-07'),
('王大衛', 'david.wang@example.com', '0922333444', '2025-04-06'),
('朱治芬', 'emily.chu@example.com', '0966778899', '2025-04-05'),
('沈一成', 'frank.shen@example.com', '0944556677', '2025-04-04'),
('魏靜安', 'grace.wei@example.com', '0911223344', '2025-04-03'),
('張智慧', 'hannah.chang@example.com', '0909888777', '2025-04-02');

SELECT * FROM Members;
*/


/*CREATE TABLE BorrowRecords (
    record_id INTEGER PRIMARY KEY AUTOINCREMENT,
    book_id INTEGER NOT NULL,
    member_id INTEGER NOT NULL,
    borrow_date DATE DEFAULT (date('now')),
    due_date DATE,
    return_date DATE,
    FOREIGN KEY (book_id) REFERENCES Books(book_id),
    FOREIGN KEY (member_id) REFERENCES Members(member_id)
);


-- 🔻 於建立BorrowRecords後，啟動TRIGGER觸發器，借書後：AvailableCopies 減 1
CREATE TRIGGER DecreaseAvailableCopies
AFTER INSERT ON BorrowRecords
FOR EACH ROW
BEGIN
    UPDATE Books
    SET AvailableCopies = AvailableCopies - 1
    WHERE book_id = NEW.book_id;
END;

-- 🔺 於建立BorrowRecords後，啟動TRIGGER觸發器，歸還書籍後：AvailableCopies 加 1
CREATE TRIGGER IncreaseAvailableCopies
AFTER UPDATE OF ReturnDate ON BorrowRecords
FOR EACH ROW
WHEN NEW.ReturnDate IS NOT NULL AND OLD.ReturnDate IS NULL
BEGIN
    UPDATE Books
    SET AvailableCopies = AvailableCopies + 1
    WHERE book_id = NEW.book_id;
END;


/*INSERT INTO BorrowRecords (book_id, member_id, borrow_date, due_date, return_date)
VALUES
(1, 1, '2025-04-11', '2025-04-18', '2025-04-15'),      -- 活著 by 王小明
(2, 2, '2025-04-10', '2025-04-17', '2025-04-16'),      -- 1984 by 張美麗
(3, 3, '2025-04-09', '2025-04-16', '2025-04-12'),      -- 追風箏的孩子 by 方可莉
(4, 4, '2025-04-08', '2025-04-15', NULL),              -- 殺死一隻知更鳥 by 李大同 (尚未歸還)
(5, 5, '2025-04-07', '2025-04-14', '2025-04-13'),      -- 百年孤寂 by 陳奕安
(6, 6, '2025-04-06', '2025-04-13', '2025-04-10'),      -- 小王子 by 王大衛
(7, 7, '2025-04-05', '2025-04-12', NULL),              -- 平凡的世界 by 朱治芬 (尚未歸還)
(8, 8, '2025-04-04', '2025-04-11', '2025-04-09'),      -- 島上書店 by 沈一成
(9, 9, '2025-04-03', '2025-04-10', NULL),              -- 天使與魔鬼 by 魏靜安 (尚未歸還)
(10, 10, '2025-04-02', '2025-04-09', '2025-04-08');    -- 哈利·波特與魔法石 by 張智慧


-- 建立書籍相關索引
#CREATE INDEX idx_books_title ON Books(title);
#CREATE UNIQUE INDEX idx_books_isbn ON Books(isbn);

-- 建立借書紀錄索引
#CREATE INDEX idx_borrow_member ON BorrowRecords(member_id);
#CREATE INDEX idx_borrow_return ON BorrowRecords(return_date);

SELECT * FROM BorrowRecords;
*/


-- 查詢某本書（例如《小王子》）的借書紀錄及其會員資料：
/*SELECT b.title, m.name, m.email, br.borrow_date, br.due_date, br.return_date
FROM BorrowRecords br
JOIN Books b ON br.book_id = b.book_id
JOIN Members m ON br.member_id = m.member_id
WHERE b.title = '小王子';
*/

- 查詢目前可借書籍數量（availablecopies）
/*SELECT title, availablecopies
FROM Books
WHERE availablecopies > 5;
*/
