

-- 建立user資料表
CREATE TABLE user (
    user_ID INTEGER PRIMARY KEY, 
    name TEXT NOT NULL, 
    phone TEXT
);

-- 查查看
select * from user

--建立一些user
INSERT INTO user (user_ID, name, phone) VALUES 
(1, '柯文喆', '0987654321'),
(2, '賴青得', '0978123456'),
(3, '徐巧猩', '0956432109'),
(4, '鍾洨平', '0911223344'),
(5, '葡萄', '0933445566'),
(6, 'Kobe Branty', '0911223344');
(7, '劉書迷', '0987654321'),
(8, '張知識', '0912345678'),
(9, '王閱讀', '0922111233'),
(10, '林書蟲', '0933445566'),
(11, '陳好奇', '0944556677'),
(12, '李愛學', '0955667788'),
(13, '方分享', '0966778899');


--以下跟上面一樣
CREATE TABLE book (
    ISBN TEXT PRIMARY KEY, 
    author TEXT NOT NULL, 
    publisher TEXT NOT NULL
);

--多插一個欄位
ALTER TABLE book ADD COLUMN title TEXT NOT NULL DEFAULT '未知書名';

select * from book

INSERT INTO book (ISBN, title, author, publisher) VALUES 
('978-7-111-60312-2', '換了位子，換了腦袋', '蔡中文', '要你命出版社'),
('978-3-16-148410-0', '囚犯的一生', '馬英丸', '123出版'),
('978-0-307-27778-7', '年紀輕輕就血尿，怎麼辦？', '小黑貓', '放放出版社'),
('978-1-891830-75-4', '小心你的EXCEL不夠強', '老貓阿爽', '毛孩出版'),
('978-0-7432-7356-0', '出來又是一條好漢', '少年股神', '韭菜的力量出版');


CREATE TABLE orders (
    order_ID INTEGER PRIMARY KEY, 
    user_ID INTEGER NOT NULL, 
    ISBN TEXT NOT NULL, 
    date DATE NOT NULL, 
    days INTEGER NOT NULL, 
    FOREIGN KEY (user_ID) REFERENCES user (user_ID),
    FOREIGN KEY (ISBN) REFERENCES book (ISBN)
);

INSERT INTO orders (order_ID, user_ID, ISBN, date, days) VALUES
(1, 6, '978-7-111-60312-2', '2025-04-14', 14);

select * from orders

INSERT INTO orders (order_ID, user_ID, ISBN, date, days) VALUES
(2, 11, '978-0-262-13472-9', '2025-04-15', 7),
(3, 12, '978-1-4039-8777-1', '2025-04-16', 14),
(4, 13, '978-3-540-88891-9', '2025-04-17', 21),
(5, 6, '978-7-111-60312-2', '2025-04-18', 7),
(6, 7, '978-0-307-27778-7', '2025-04-19', 10),
(7, 8, '978-3-16-148410-0', '2025-04-20', 15),
(8, 9, '978-0-7432-7356-0', '2025-04-21', 20),
(9, 10, '978-1-891830-75-4', '2025-04-22', 5),
(10, 11, '978-0-262-13472-9', '2025-04-23', 12),
(11, 12, '978-1-4039-8777-1', '2025-04-24', 7),
(12, 13, '978-3-540-88891-9', '2025-04-25', 14),
(13, 6, '978-7-111-60312-2', '2025-04-26', 9),
(14, 7, '978-0-7432-7356-0', '2025-04-27', 6),
(15, 8, '978-3-16-148410-0', '2025-04-28', 18),
(16, 9, '978-1-891830-75-4', '2025-04-29', 10),
(17, 10, '978-0-262-13472-9', '2025-04-30', 20),
(18, 11, '978-1-4039-8777-1', '2025-05-01', 14),
(19, 12, '978-3-540-88891-9', '2025-05-02', 7),
(20, 13, '978-7-111-60312-2', '2025-05-03', 10);





SELECT 
    orders.user_ID, 
    user.name, 
    COUNT(orders.order_ID) AS BorrowCount
FROM 
    orders
JOIN 
    user ON orders.user_ID = user.user_ID
GROUP BY 
    orders.user_ID, user.name;