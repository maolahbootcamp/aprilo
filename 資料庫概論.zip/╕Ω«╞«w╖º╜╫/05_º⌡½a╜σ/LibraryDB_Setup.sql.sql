--建立書庫存表
CREATE TABLE IF NOT EXISTS Book_Stock(
 Book_Barcode TEXT PRIMARY KEY,
 Book_Name TEXT,
 ISBN TEXT,
 Writer TEXT,
 Publisher_ID INTEGER,
 Genre_ID INTEGER,
 Stock_Amount INTEGER,
 Price INTEGER,
 FOREIGN KEY (Publisher_ID) REFERENCES Publisher(Publisher_ID),
 FOREIGN KEY (Genre_ID) REFERENCES Genre(Genre_ID)
);
--建立出版商對照表
CREATE TABLE IF NOT EXISTS Publisher(
  Publisher_ID INTEGER PRIMARY KEY,
  Publisher_Name TEXT
);
--建立分類書表
CREATE TABLE IF NOT EXISTS Genre(
 Genre_ID INTEGER PRIMARY KEY,
 Genre_Name TEXT
);
--建立借閱人資料表
CREATE TABLE IF NOT EXISTS Borrower(
 Borrower_ID INTEGER PRIMARY KEY AUTOINCREMENT,
 Name TEXT,
 Birthday DATE,
 Sex TEXT,
 Phone_Number TEXT,
 Email TEXT
);
--建立借閱紀錄表
CREATE TABLE IF NOT EXISTS Borrow_Record(
 Record_ID INTEGER PRIMARY KEY AUTOINCREMENT,
 Book_Barcode TEXT,
 Borrower_ID INTEGER,
 Date_Of_Borrow DATE,
 Date_Of_Return DATE,
 FOREIGN KEY (Book_Barcode) REFERENCES Book_Stock(Book_Barcode),
 FOREIGN KEY (Borrower_ID) REFERENCES Borrower(Borrower_ID)
);
--建立保留預定書表
CREATE TABLE IF NOT EXISTS Book_Reservation(
 Reservation_ID INTEGER PRIMARY KEY AUTOINCREMENT,
 Book_Barcode INTEGER,
 Borrower_ID TEXT,
 Reservation_Date DATE DEFAULT (DATE('now')),
 Status TEXT DEFAULT 'Pending', -- 'Pending', 'Fulfilled', 'Cancelled'
 FOREIGN KEY (Book_Barcode) REFERENCES Book_Stock(Book_Barcode),
 FOREIGN KEY (Borrower_ID) REFERENCES Borrower(Borrower_ID)
);
--插入出版商資料
INSERT INTO Publisher(Publisher_ID, Publisher_Name)VALUES
 (1, 'Penguin Random House'),
 (2, 'Oxford University Press'),
 (3, 'Simon & Schuster'),
 (4, 'Pearson Education');
--插入書分類資料
INSERT INTO Genre (Genre_ID, Genre_Name)VALUES
 (1, 'Fiction'),
 (2, 'Finance'),
 (3, 'Political'),
 (4, 'Psychology'),
 (5, 'Science'),
 (6, 'Romance'),
 (7, 'Biography'),
 (8, 'Historical');
--插入書明細資料
INSERT INTO Book_Stock (
  Book_Barcode, Book_Name, ISBN, Writer, Publisher_ID, Genre_ID, Stock_Amount, Price
)VALUES
 (1001, 'The Silent Mind', '9780143127741', 'John Doe', 1, 4, 2, 450),
 (1002, 'Rich Habits', '9780062315007', 'Jane Smith', 2, 2, 4, 520),
 (1003, 'The Last Kingdom', '9781501141117', 'David Harper', 2, 8, 3, 600),
 (1004, 'Galaxy Quest', '9780345539434', 'Amy Tan', 3, 5, 1, 490),
 (1005, 'The Love Code', '9780804176321', 'Catherine Lin', 4, 6, 4, 390),
 (1006, 'Political Chessboard', '9780374533557', 'Henry Lee', 4, 3, 1, 580),
 (1007, 'Atomic Biology', '9780198758884', 'Dr. Elena Fox', 1, 5, 3, 720),
 (1008, 'Finance for Beginners', '9781119207433', 'Michael Young', 2, 2, 2, 350),
 (1009, 'Memoirs of a Leader', '9780134093413', 'Sarah Grant', 3, 7, 1, 640),
 (1010, 'Hearts in Winter', '9781101985305', 'Lily Chen', 4, 6, 3, 410),
 (1011, 'Fictional Realms', '9780140449136', 'Tom Rivers', 1, 1, 2, 480),
 (1012, 'Smart Investing', '9781259869203', 'Nina Brooks', 2, 2, 3, 530),
 (1013, 'Voices of Power', '9780307388774', 'Richard Allen', 4, 3, 4, 610),
 (1014, 'The Human Brain', '9780195377682', 'Laura Gray', 1, 4, 1, 730),
 (1015, 'Celestial Horizons', '9780553418026', 'Brian Wu', 3, 5, 2, 520),
 (1016, 'Summer of Love', '9780451474002', 'Emily Lee', 4, 6, 3, 390),
 (1017, 'Life of a Genius', '9780679734529', 'Dr. Samir Patel', 3, 7, 4, 690),
 (1018, 'Ancient Empires', '9780525555372', 'Kelly Watson', 2, 8, 3, 610),
 (1019, 'Fictional Realms 2', '9780143127550', 'Tom Rivers', 1, 1, 2, 470),
 (1020, 'The Budget Blueprint', '9781119562211', 'Nathan Drake', 2, 2, 4, 540),
 (1021, 'Diplomatic Games', '9780307947056', 'Linda Grant', 4, 3, 1, 580),
 (1022, 'Mind Matters', '9780199329228', 'Dr. Alice Moore', 1, 4, 3, 720),
 (1023, 'Space & Beyond', '9780062315008', 'Oliver Cruz', 3, 5, 2, 510),
 (1024, 'Hearts in Spring', '9780345539441', 'Lily Chen', 4, 6, 4, 430),
 (1025, 'Biography of a Dreamer', '9780131101631', 'Erika Miles', 3, 7, 1, 600),
 (1026, 'Revolution Past', '9780525436145', 'Howard Bell', 2, 8, 3, 620),
 (1027, 'Stories Untold', '9780142000670', 'Amanda Yu', 1, 1, 2, 460),
 (1028, 'Money Sense', '9781260143160', 'Daniel Lee', 2, 2, 3, 530),
 (1029, 'Government Logic', '9780374531263', 'Charles Adams', 4, 3, 1, 610),
 (1030, 'Brain on Fire', '9780199235971', 'Dr. Jean Morgan', 1, 4, 2, 750),
 (1031, 'Astro Discoveries', '9780553418033', 'Brian Wu', 3, 5, 4, 540),
 (1032, 'Romance in Paris', '9780451474019', 'Emily Lee', 4, 6, 1, 370),
 (1033, 'The Maverick', '9780679734536', 'Dr. Samir Patel', 3, 7, 3, 670),
 (1034, 'Past Kingdoms', '9780525555389', 'Kelly Watson', 2, 8, 2, 590),
 (1035, 'The Long Journey', '9780140449143', 'Tom Rivers', 1, 1, 4, 450),
 (1036, 'Financial IQ', '9781119372636', 'Nina Brooks', 2, 2, 3, 560),
 (1037, 'Power Moves', '9780307388785', 'Richard Allen', 4, 3, 2, 600),
 (1038, 'Deep Psychology', '9780199285532', 'Laura Gray', 1, 4, 1, 740),
 (1039, 'Mars Mission', '9780345539458', 'Oliver Cruz', 3, 5, 4, 520),
 (1040, 'Hearts Collide', '9780804176338', 'Lily Chen', 4, 6, 2, 400),
 (1041, 'The Visionary', '9780679734543', 'Erika Miles', 3, 7, 3, 650),
 (1042, 'History Rewritten', '9780525436152', 'Howard Bell', 2, 8, 1, 580),
 (1043, 'Whispers of the Past', '9780142000687', 'Amanda Yu', 1, 1, 2, 490),
 (1044, 'Investor’s Path', '9781260143177', 'Nathan Drake', 2, 2, 3, 520),
 (1045, 'Democracy Decoded', '9780374531270', 'Linda Grant', 4, 3, 1, 630),
 (1046, 'Cognitive Waves', '9780199329237', 'Dr. Alice Moore', 1, 4, 4, 770),
 (1047, 'Beyond Stars', '9780062315015', 'Brian Wu', 3, 5, 3, 500),
 (1048, 'Romantic Trails', '9780451474026', 'Emily Lee', 4, 6, 2, 410),
 (1049, 'Legacy of Greatness', '9780131101648', 'Dr. Samir Patel', 3, 7, 1, 670),
 (1050, 'Historical Echoes', '9780525555396', 'Kelly Watson', 2, 8, 4, 600);
--插入借閱人資料
 INSERT INTO Borrower (Name, Birthday, Sex, Phone_Number, Email)VALUES
 ('Aoife O’Connor', '1992-07-15', 'F', '07123 456789', 'aoife.oconnor@example.com'),
 ('Brendan Murphy', '1988-04-22', 'M', '07234 567890', 'brendan.murphy@example.com'),
 ('Caoimhe Byrne', '1995-01-30', 'F', '07345 678901', 'caoimhe.byrne@example.com'),
 ('Darragh Kelly', '1980-11-12', 'M', '07456 789012', 'darragh.kelly@example.com'),
 ('Eimear Gallagher', '1990-09-05', 'F', '07567 890123', 'eimear.gallagher@example.com'),
 ('Fionn McCarthy', '1986-02-28', 'M', '07678 901234', 'fionn.mccarthy@example.com'),
 ('Gráinne O’Neill', '1999-06-18', 'F', '07789 012345', 'grainne.oneill@example.com'),
 ('Hugh O’Sullivan', '1985-12-09', 'M', '07890 123456', 'hugh.osullivan@example.com'),
 ('Iarlaith Fitzgerald', '2002-03-14', 'M', '07901 234567', 'iarlaith.fitzgerald@example.com'),
 ('Jarlath O’Reilly', '1993-10-01', 'M', '07012 345678', 'jarlath.oreilly@example.com'),
 ('Kiera Collins', '2000-05-07', 'F', '07134 567890', 'kiera.collins@example.com'),
 ('Liam Donnelly', '1989-08-17', 'M', '07245 678901', 'liam.donnelly@example.com'),
 ('Maeve Duffy', '1996-12-23', 'F', '07356 789012', 'maeve.duffy@example.com'),
 ('Niamh Brennan', '1997-07-02', 'F', '07467 890123', 'niamh.brennan@example.com'),
 ('Oisín Quinn', '1991-01-25', 'M', '07578 901234', 'oisin.quinn@example.com'),
 ('Pádraig Murphy', '2003-10-16', 'M', '07689 012345', 'padraig.murphy@example.com'),
 ('Róisín Walsh', '1994-05-04', 'F', '07790 123456', 'roisin.walsh@example.com'),
 ('Seán Lynch', '1983-03-09', 'M', '07801 234567', 'sean.lynch@example.com'),
 ('Tadhg Fitzpatrick', '1998-11-27', 'M', '07912 345678', 'tadhg.fitzpatrick@example.com'),
 ('Úna O’Mahony', '2001-08-13', 'F', '07023 456789', 'una.omahony@example.com');
--插入借閱紀錄
INSERT INTO Borrow_Record (Book_Barcode, Borrower_ID, Date_Of_Borrow, Date_Of_Return) VALUES
 (1001, 16, DATE('2025-03-01'), DATE('2025-03-12')),
 (1002, 3, DATE('2025-03-03'), DATE('2025-03-17')),
 (1003, 10, DATE('2025-03-05'), DATE('2025-03-20')),
 (1004, 7, DATE('2025-03-07'), DATE('2025-03-18')),
 (1005, 13, DATE('2025-03-09'), DATE('2025-03-19')),
 (1006, 4, DATE('2025-03-12'), DATE('2025-03-15')),
 (1007, 5, DATE('2025-03-14'), DATE('2025-03-21')),
 (1008, 18, DATE('2025-03-06'), DATE('2025-03-15')),
 (1009, 19, DATE('2025-03-04'), DATE('2025-03-11')),
 (1010, 12, DATE('2025-03-02'), DATE('2025-03-10')),
 (1011, 1, DATE('2025-03-08'), DATE('2025-03-13')),
 (1012, 2, DATE('2025-03-10'), DATE('2025-03-17')),
 (1013, 14, DATE('2025-03-12'), DATE('2025-03-15')),
 (1014, 11, DATE('2025-03-04'), DATE('2025-03-11')),
 (1015, 6, DATE('2025-03-01'), DATE('2025-03-14')),
 (1016, 17, DATE('2025-03-02'), DATE('2025-03-08')),
 (1017, 4, DATE('2025-03-10'), DATE('2025-03-13')),
 (1018, 9, DATE('2025-03-05'), DATE('2025-03-18')),
 (1019, 15, DATE('2025-03-02'), DATE('2025-03-10')),
 (1020, 8, DATE('2025-03-06'), DATE('2025-03-13')),
 (1021, 1, DATE('2025-03-07'), DATE('2025-03-14')),
 (1022, 6, DATE('2025-03-01'), DATE('2025-03-13')),
 (1023, 3, DATE('2025-03-03'), DATE('2025-03-17')),
 (1024, 10, DATE('2025-03-04'), DATE('2025-03-12')),
 (1025, 7, DATE('2025-03-06'), DATE('2025-03-12')),
 (1026, 5, DATE('2025-03-08'), DATE('2025-03-18')),
 (1027, 12, DATE('2025-03-02'), DATE('2025-03-10')),
 (1028, 19, DATE('2025-03-05'), DATE('2025-03-18')),
 (1029, 8, DATE('2025-03-03'), DATE('2025-03-10')),
 (1030, 14, DATE('2025-03-09'), DATE('2025-03-17')),
 (1031, 13, DATE('2025-03-06'), DATE('2025-03-16')),
 (1032, 20, DATE('2025-03-04'), DATE('2025-03-11')),
 (1033, 11, DATE('2025-03-10'), DATE('2025-03-14')),
 (1034, 9, DATE('2025-03-05'), DATE('2025-03-14')),
 (1035, 17, DATE('2025-03-01'), DATE('2025-03-13')),
 (1036, 4, DATE('2025-03-03'), DATE('2025-03-12')),
 (1037, 16, DATE('2025-03-09'), DATE('2025-03-19')),
 (1038, 13, DATE('2025-03-07'), DATE('2025-03-20')),
 (1039, 14, DATE('2025-03-02'), DATE('2025-03-17')),
 (1040, 6, DATE('2025-03-01'), DATE('2025-03-12')),
 (1041, 1, DATE('2025-03-03'), DATE('2025-03-13')),
 (1042, 2, DATE('2025-03-06'), DATE('2025-03-12')),
 (1043, 3, DATE('2025-03-04'), DATE('2025-03-11')),
 (1044, 5, DATE('2025-03-02'), DATE('2025-03-16')),
 (1045, 10, DATE('2025-03-06'), DATE('2025-03-15')),
 (1046, 8, DATE('2025-03-02'), DATE('2025-03-13')),
 (1047, 15, DATE('2025-03-04'), DATE('2025-03-12')),
 (1048, 12, DATE('2025-03-07'), DATE('2025-03-20')),
 (1049, 19, DATE('2025-03-01'), DATE('2025-03-18')),
 (1050, 6, DATE('2025-03-13'), DATE('2025-03-20'));
--插入保留預定資料
INSERT INTO Book_Reservation (Book_Barcode, Borrower_ID, Status) VALUES
 (1003, 5, 'Pending'),
 (1008, 2, 'Pending'),
 (1012, 12, 'Pending'),
 (1016, 7, 'Pending'),
 (1020, 14, 'Pending'),
 (1024, 3, 'Pending'),
 (1028, 6, 'Pending'),
 (1032, 9, 'Pending'),
 (1036, 10, 'Pending'),
 (1040, 1, 'Pending'),
 (1044, 4, 'Pending'),
 (1048, 13, 'Pending'),
 (1001, 16, 'Pending'),
 (1009, 18, 'Pending'),
 (1014, 15, 'Pending');
 
---trigger---
--借書插入前確認
CREATE TRIGGER trg_check_stock
BEFORE INSERT ON Borrow_Record
FOR EACH ROW
BEGIN   
    SELECT CASE
        WHEN (SELECT Stock_Amount FROM Book_Stock WHERE Book_Barcode = NEW.Book_Barcode) <= 0 THEN
            RAISE(ABORT, 'Book out of stock')
    END;
END;

--借書插入後扣庫存
CREATE TRIGGER Decrease_Stock_After_Borrow
AFTER INSERT ON Borrow_Record
FOR EACH ROW
BEGIN
  UPDATE Book_Stock
  SET Stock_Amount = Stock_Amount - 1
  WHERE Book_Barcode = NEW.Book_Barcode;
END;
--還書後庫存+1
CREATE TRIGGER Increase_Stock_After_Return
AFTER UPDATE OF Date_Of_Return ON Borrow_Record
FOR EACH ROW
WHEN OLD.Date_Of_Return IS NULL AND NEW.Date_Of_Return IS NOT NULL
BEGIN
  UPDATE Book_Stock
  SET Stock_Amount = Stock_Amount + 1
  WHERE Book_Barcode = NEW.Book_Barcode;
END;

---測試trigger. barcode 1004只有兩本, 第二筆成功跳錯無法借閱
INSERT INTO Borrow_Record (Book_Barcode, Borrower_ID, Date_Of_Borrow) VALUES
(1004, 7, '2025-01-21')
INSERT INTO Borrow_Record (Book_Barcode, Borrower_ID, Date_Of_Borrow) VALUES
(1004, 11, '2025-01-23')
---測試trigger. 還書後成功加回庫存
UPDATE Borrow_Record
SET Date_Of_Return = '2025-01-31'
WHERE Book_Barcode = 1004
  AND Borrower_ID = 7
  AND Date_Of_Borrow = '2025-01-21'
  AND Record_ID = 55
  AND Date_Of_Return IS NULL;


---transaction---
----借書鎖定
BEGIN TRANSACTION;
INSERT INTO Borrow_Record (Book_Barcode, Borrower_ID, Date_Of_Borrow)
SELECT 1008, 1, '2023-10-01'
WHERE EXISTS (
  SELECT 1 FROM Book_Stock 
  WHERE Book_Barcode = 1008 AND Stock_Amount >= 1
);
UPDATE Book_Stock
SET Stock_Amount = Stock_Amount - 1
WHERE Book_Barcode = 1008 AND Stock_Amount >= 1;
COMMIT;

---還書鎖定
BEGIN TRANSACTION;
UPDATE Borrow_Record
SET Date_Of_Return = '2023-10-12'
WHERE Book_Barcode = 1008 
  AND Borrower_ID = 1
  AND Date_Of_Return IS NULL;  
UPDATE Book_Stock
SET Stock_Amount = Stock_Amount + 1
WHERE Book_Barcode = 1008 
  AND Stock_Amount >= 0;
COMMIT;

---書本被借閱紀錄
SELECT B.Book_Barcode, B.Book_Name,Bo.Record_ID AS Borrow_RecordID, Name AS Borrower_Name
FROM Book_Stock B JOIN Borrow_Record Bo JOIN Borrower Bor
ON B.Book_Barcode = Bo.Book_Barcode AND Bo.Borrower_ID = Bor.Borrower_ID
WHERE B.Book_Barcode = 1008 

--

select  * from Book_Reservation
where Book_Barcode = 1005;

--書本預定檢查庫存
BEGIN TRANSACTION;
INSERT INTO Book_Reservation (Book_Barcode, Borrower_ID, Status)
SELECT '1005', 7,             
    CASE 
        WHEN (SELECT Stock_Amount FROM Book_Stock WHERE Book_Barcode = '1005') > 0 
        THEN 'Fulfilled'
        ELSE 'Pending'
    END;
COMMIT;

--建立罰金計算view
CREATE VIEW IF NOT EXISTS Fine AS
SELECT b.Record_ID, b.Book_Barcode, b.Borrower_ID, br.Name, 
DATE(b.Date_Of_Borrow, '+14 days') AS Due_Day,
CASE 
    WHEN b.Date_Of_Return IS NOT NULL 
        AND b.Date_Of_Return > DATE(b.Date_Of_Borrow, '+14 days')
    THEN 
        (julianday(b.Date_Of_Return) - julianday(DATE(b.Date_Of_Borrow, '+14 days'))) * 20
    ELSE 0
END AS Penalty
FROM Borrow_Record b 
JOIN Borrower br ON b.Borrower_ID = br.Borrower_ID;
--測試罰金計算
INSERT INTO Borrow_Record(Book_Barcode, Borrower_ID, Date_Of_Borrow) VALUES
(1020, 17, '2024-04-01')
UPDATE Borrow_Record
SET Date_Of_Return = '2024-04-20'
WHERE Book_Barcode = 1020
  AND Borrower_ID = 17
  AND Date_Of_Borrow = '2024-04-01'
  AND Record_ID = 56
  AND Date_Of_Return IS NULL;
--呼叫罰金表  
select * from Fine
WHERE penalty > 0

--建立查詢書本借閱次數INDEX
CREATE INDEX IF NOT EXISTS idx_borrow_record_book_barcode
ON Borrow_Record (Book_Barcode);
透過INDEX搜尋書借閱次數
SELECT * FROM Borrow_Record WHERE Book_Barcode = 1004;
--查詢書籍庫存
SELECT * FROM Book_Stock WHERE Stock_Amount > 0;
--刪除借書人
DELETE FROM Borrower WHERE Borrower_ID = 1;
--新增欄位到Publish表格
ALTER TABLE Publisher ADD COLUMN Address TEXT;
--刪除Publisher資料表欄位
ALTER TABLE Publisher
DROP COLUMN Address;

