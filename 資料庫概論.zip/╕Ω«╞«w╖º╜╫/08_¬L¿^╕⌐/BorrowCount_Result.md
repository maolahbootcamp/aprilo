# 查詢全部書籍返回借閱次數結果

書名            被借閱次數    返還次數
--------------+-----------+----------+
Code Love     |          7|         7|
Code Secret   |          1|         1|
Dragon Dragon |          0|         0|
Dragon Secret |          7|         7|
Dream Code    |          0|         0|
Dream Dream   |          0|         0|
Dream Journey |          1|         1|
Dream Love    |          0|         0|
Empire Code   |          1|         1|
Empire Dragon |          1|         1|
Journey Dragon|          0|         0|
Journey Dream |          0|         0|
Journey Love  |          1|         1|
Journey Star  |          4|         4|
Love Dream    |          1|         1|
Love Empire   |          0|         0|
Love Shadow   |          0|         0|
Mystery Secret|          0|         0|
Mystery Star  |          1|         1|
Secret Dream  |          0|         0|
Secret Journey|          0|         0|
Shadow Empire |          1|         1|
Shadow Love   |          0|         0|
Shadow Secret |          0|         0|
Shadow Star   |          0|         0|
Star Love     |         11|        11|

# 查詢每位借閱者(有借書證者)返回借閱次數結果

借閱者姓名         借閱次數 返還次數
-----------------+-------+--------+
librarian_account|      0|       0|
Anna White       |      1|       1|
Laura Martin     |      5|       5|
James Taylor     |      2|       2|
Michael Smith    |      1|       1|
Emily Martin     |      5|       5|
Anna Martin      |      3|       3|
Emily Smith      |      1|       1|
Michael Smith    |      1|       1|
Emily Brown      |      3|       3|
James Wilson     |      0|       0|
David Brown      |      1|       1|
David Lee        |      1|       1|
James Clark      |      0|       0|
James Clark      |      2|       2|
James Wilson     |      2|       2|
David Lee        |      2|       2|
James Lewis      |      3|       3|
Anna Taylor      |      1|       1|
Laura Brown      |      0|       0|
James Taylor     |      3|       3|  

# 查詢目前書籍狀態

書名          |可借閱數量| 未歸還數量|
--------------+-----------+-----------+
Code Love     |          4|          2|
Code Secret   |          5|          1|
Dragon Dragon |          6|          0|
Dragon Secret |          1|          2|
Dream Code    |          6|          0|
Dream Dream   |          1|          0|
Dream Journey |          7|          0|
Dream Love    |          7|          0|
Empire Code   |          3|          0|
Empire Dragon |          6|          1|
Journey Dragon|          4|          0|
Journey Dream |          6|          0|
Journey Love  |          5|          1|
Journey Star  |          1|          0|
Love Dream    |          4|          0|
Love Empire   |          2|          0|
Love Shadow   |         10|          0|
Mystery Secret|          6|          0|
Mystery Star  |          5|          1|
Secret Dream  |          6|          0|
Secret Journey|          6|          0|
Shadow Empire |          6|          1|
Shadow Love   |          6|          0|
Shadow Secret |          8|          0|
Shadow Star   |          4|          0|
Star Love     |          2|          1|

