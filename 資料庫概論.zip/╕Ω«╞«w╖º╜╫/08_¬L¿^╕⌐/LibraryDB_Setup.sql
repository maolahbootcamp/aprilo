-- 圖書館管理資料庫建立與資料插入指令

--1. 建立資料表(DDL)

--書籍資料	book_data
CREATE TABLE IF NOT EXISTS book_data(
isbn TEXT PRIMARY KEY,--IBSN
title TEXT,--書名
author TEXT,--作者
book_location TEXT,--存放位置
book_n INTEGER--書籍數量
);

--借閱者資料	bookborrower_data
CREATE TABLE IF NOT EXISTS bookborrower_data(
borrower_card_id TEXT PRIMARY KEY,	--借書證號
national_id	TEXT UNIQUE,	--身分證號
borrower_name	TEXT,	--姓名
borrower_tel	TEXT UNIQUE	--連絡電話
);

--借閱紀錄	record_data		
CREATE TABLE IF NOT EXISTS record_data(
record_id	TEXT	PRIMARY KEY,  --借閱紀錄id
record_date	TEXT,	--借閱日期
borrower_card_id TEXT,	--借書證號
isbn	TEXT,	--圖書編碼
return_date	TEXT,	--歸還日期

FOREIGN KEY (borrower_card_id) REFERENCES bookborrower_data(borrower_card_id),
FOREIGN KEY (isbn) REFERENCES book_data(isbn)
);

-- 建立索引，提高查詢效能
CREATE INDEX IF NOT EXISTS idx_record_isbn ON record_data(isbn);
CREATE INDEX IF NOT EXISTS idx_record_record_date ON record_data(record_date);
CREATE INDEX IF NOT EXISTS idx_record_return_date ON record_data(return_date);
CREATE INDEX IF NOT EXISTS idx_bookborrower_borrower_card_id ON bookborrower_data(borrower_card_id);

-- 2. 插入資料（DML）

--插入書籍資料	book_data
INSERT INTO book_data(isbn,title,author,book_location,book_n)VALUES
('9791615141312','Star Love','Anna Clark','A',3),
('9794444444449','Dream Love','Anna Johnson','A',7),
('9790987654322','Dragon Secret','David Johnson','A',3),
('9785555555550','Empire Code','David Martin','A',3),
('9787788990012','Secret Journey','David Smith','A',6),
('9780987654321','Dragon Dragon','David White','A',6),
('9787777777772','Journey Dragon','David White','B',4),
('9781122334456','Love Dream','David White','B',4),
('9789999999994','Journey Love','Emily Taylor','B',6),
('9792222222227','Dream Dream','James Smith','B',1),
('97811111111161','Dream Code','James Wilson','B',6),
('9798888888883','Journey Dream','James Wilson','B',6),
('9796677889901','Secret Dream','John Brown','B',6),
('9792233445567','Love Empire','John Clark','C',2),
('9791234567891','Code Secret','John Johnson','C',6),
('9783333333338','Dream Journey','Kate Johnson','C',7),
('9781234567890','Code Love','Kate Taylor','C',6),
('9785566778890','Mystery Star','Kate Taylor','C',6),
('9790000000005','Journey Star','Laura Johnson','C',1),
('9798899001123','Shadow Empire','Robert Johnson','C',7),
('9796666666661','Empire Dragon','Robert Smith','D',7),
('9783344556678','Love Shadow','Sarah Johnson','D',10),
('9789900112234','Shadow Love','Sarah Smith','D',6),
('9791011121315','Shadow Secret','Sarah Taylor','D',8),
('9794455667789','Mystery Secret','Sarah White','D',6),
('9781213141516','Shadow Star','Sarah Wilson','D',4);

--插入借閱者資料	bookborrower_data
INSERT INTO bookborrower_data(borrower_card_id,national_id,borrower_name,borrower_tel)VALUES
('BRW0000','A123456789','librarian_account','0912345678'),
('BRW0001','H226579142','Anna White','0978605547'),
('BRW0002','H222766729','Laura Martin','0926127929'),
('BRW0003','R120577631','James Taylor','0911844048'),
('BRW0004','I124483506','Michael Smith','0947575749'),
('BRW0005','U228464698','Emily Martin','0939603733'),
('BRW0006','F227002566','Anna Martin','0980006681'),
('BRW0007','O125074506','Emily Smith','0909862444'),
('BRW0008','N125902682','Michael Smith','0934741006'),
('BRW0009','C222913219','Emily Brown','0991028686'),
('BRW0010','Z228824658','James Wilson','0995958551'),
('BRW0011','K225653446','David Brown','0965996353'),
('BRW0012','R225978279','David Lee','0968659053'),
('BRW0013','U129412912','James Clark','0988444279'),
('BRW0014','H226256490','James Clark','0970520634'),
('BRW0015','A125737079','James Wilson','0984081489'),
('BRW0016','G223335940','David Lee','0912598573'),
('BRW0017','P222833759','James Lewis','0966539399'),
('BRW0018','T129491116','Anna Taylor','0936843613'),
('BRW0019','K224694516','Laura Brown','0908791006'),
('BRW0020','K224667485','James Taylor','0932953319');

--插入借閱紀錄資料	record_data
INSERT INTO record_data(record_id,record_date,borrower_card_id,isbn,return_date)VALUES
('REC0001','20230101','BRW0001','9791615141312','20230121'),
('REC0002','20230215','BRW0002','9791615141312','20230220'),
('REC0003','20230215','BRW0002','9791615141312','20230220'),
('REC0004','20230315','BRW0002','9791615141312','20230401'),
('REC0005','20230315','BRW0002','9791615141312','20230401'),
('REC0006','20230528','BRW0002','9790987654322','20230529'),
('REC0007','20230222','BRW0003','9791615141312','20230306'),
('REC0008','20230222','BRW0003','9790987654322','20230306'),
('REC0009','20240501','BRW0004','9790000000005','20240516'),
('REC0010','20240506','BRW0005','9785555555550','20240506'),
('REC0011','20240506','BRW0005','9790987654322','none'),
('REC0012','20230810','BRW0005','9791615141312','20230818'),
('REC0013','20230810','BRW0005','9791615141312','20230818'),
('REC0014','20230811','BRW0005','9790987654322','20230815'),
('REC0015','20230828','BRW0006','9791615141312','20230901'),
('REC0016','20250301','BRW0006','9781122334456','20250316'),
('REC0017','20250316','BRW0006','9789999999994','none'),
('REC0018','20230901','BRW0007','9791615141312','20230920'),
('REC0019','20240520','BRW0008','9790000000005','20240602'),
('REC0020','20230825','BRW0009','9790987654322','20230901'),
('REC0021','20250318','BRW0009','9785566778890','none'),
('REC0022','20240102','BRW0009','9791615141312','none'),
('REC0023','20230815','BRW0011','9790987654322','20230825'),
('REC0024','20240618','BRW0012','9790000000005','20240630'),
('REC0025','20230901','BRW0014','9790987654322','none'),
('REC0026','20250101','BRW0014','9791234567891','none'),
('REC0027','20250115','BRW0015','9783333333338','20250201'),
('REC0028','20250115','BRW0015','9781234567890','none'),
('REC0029','20250105','BRW0016','9781234567890','20250120'),
('REC0030','20250105','BRW0016','9781234567890','20250120'),
('REC0031','20250312','BRW0017','9781234567890','20250410'),
('REC0032','20250312','BRW0017','9781234567890','20250410'),
('REC0033','20250312','BRW0017','9781234567890','20250410'),
('REC0034','20250408','BRW0018','9781234567890','none'),
('REC0035','20240801','BRW0020','9790000000005','20240815'),
('REC0036','20250401','BRW0020','9798899001123','none'),
('REC0037','20250401','BRW0020','9796666666661','none');

-- 3. 查詢資料（DQL）

--查詢"每本書"返回借閱次數結果
SELECT book_data.title AS 書名,
       COUNT(record_data.record_date) AS 被借閱次數,
       COUNT(record_data.return_date) AS 返還次數
FROM book_data
LEFT JOIN record_data ON book_data.isbn = record_data.isbn
GROUP BY book_data.title;

--查詢"每個人"返回借閱次數結果
SELECT 
    bookborrower_data.borrower_name AS 借閱者姓名,
    COUNT(record_data.record_date) AS 借閱次數,
    COUNT(record_data.return_date) AS 返還次數
FROM 
    bookborrower_data
LEFT JOIN 
    record_data  ON bookborrower_data.borrower_card_id = record_data.borrower_card_id
GROUP BY 
    bookborrower_data.borrower_card_id;
--查詢目前書籍狀態
SELECT 
    book_data.title AS 書名,
    book_data.book_n - IFNULL(SUM(record_data.return_date = 'none'), 0) AS 可借閱數量,  
    -- 可借閱數量:總數量(book_data.book_n)-未歸還數量
    IFNULL(SUM(record_data.return_date = 'none'), 0) AS 未歸還數量  
    -- 未歸還數量(record_data.return_date = 'none')
    --(用IFNULL處理"沒有未歸還的書籍"或"沒有任何借閱紀錄的書籍")
FROM book_data
LEFT JOIN record_data ON book_data.isbn = record_data.isbn
GROUP BY book_data.title, book_data.book_n;
