# 圖書館借閱記錄資料庫專案

## 專案簡述
圖書館資料庫，可以記錄、查詢讀者借閱記錄。且可查詢書籍，及讀者詳細資料。 

## 資料模型與正規化說明
![ER-Diagram](./ER-Diagram.png "ER-Diagram")

### 設計檢討
- 依照 ER-Diagram，分別製作書籍、借閱記錄、使用者，三個表。但書籍可能會同一本書購買多本，造成大量資料重複。
- 所以把書籍詳細資料獨立，以ISBN關聯，這樣書籍只需要記錄ISBN就能與**書籍詳細資料**結合查到詳細資料。
- 雖然書籍詳細資料中：尚有多項可以拆分，但為了方便查詢，故不再細分(反正規化)。

**正規化後的資料表：**
```
使用者姓名,生日,電話,E-mail,地址, 
ISBN,書名,作者,出版商,出版年,頁數,分類,語言,分類號,版本,出版地,購入價格
借書日期,還書日期,借閱者,書名
```
## 資料庫表格結構

### 1. 書籍詳細資料 (isbndata)
- isbn (TEXT) 書籍詳細資料唯一識別碼，主鍵，ISBN
- bname (TEXT) 一定要填， 書名
- author (TEXT) 預設 NULL， 作者
- publisher (TEXT) 預設 NULL， 發行者
- publish_year (TEXT) 預設 NULL， 發行年
- paperback (INTERGER) 預設 NULL， 頁數
- tags (TEXT) 預設 NULL， 分類
- lang (TEXT) 預設 NULL， 語言
- kind (TEXT) 預設 NULL， 分類號
- edition (TEXT) 預設 NULL， 版本
- publisher_loc (TEXT) 預設 NULL， 發行地



### 2. 書籍資料(books)
- bookid (INTERGER) 書籍唯一識別碼，主鍵，自動產生流水號， 書籍id
- isbn 一定要填，外鍵，ISBN
- price (REAL) 一定要填  意思一下，檢查價格>0


### 3. 使用者 (users)
- userid (INTERGER) 使用者唯一識別碼，主鍵，自動產生流水號， 使用者id
- identify (TEXT) 預設 NULL， 身份證字號
- uname (TEXT) 一定要填， 姓名
- birthday (TEXT) 預設 NULL， 生日
- phone (TEXT) 預設 NULL，電話
- email (TEXT) 預設 NULL，E-mail
- address (TEXT) 預設 NULL， 地址

### 4. 借閱記錄 (rentrecord)
- rentid (INTERGER) 借閱記錄唯一識別碼，主鍵， 自動產生流水號， 借閱記錄id
- bookid (INTERGER) 一定要填，外鍵， 使用者id
- userid (INTERGER) 一定要填，外鍵， 書籍id
- adate (TEXT) 預設今天， 預約日期
- bdate (TEXT) 預設 NULL，借書日期
- rdate (TEXT) 預設 NULL，還書日期

## 資料庫操作指南
1. 命令提示字元執行 `sqlite3`
2. 在 sqlite> 提示 執行 `.read LibraryDB_Setup.sql` 建立資料庫結構並插入初始資料。
3. 查詢結果存儲在 `BorrowCount_Result.md` 中。

## 資料庫視圖關係

使用者(多) >---- 借閱記錄(多) ----< 書(多)
![ER-Diagram](./ER-Diagram.png "ER-Diagram")

## 索引設計
為了提高查詢性能，資料庫包含以下索引：
- **書籍詳細資料** 表的 **ISBN** 索引
- **使用者**  的 **身份證字號** 索引
- **借閱記錄** 的 **借閱日期** 索引

## 資料完整性約束
1. 主鍵約束：每個表都有明確的主鍵
2. 外鍵約束：所有關聯都有正確的外鍵引用
3. CHECK約束：確保數量、價格等數值欄位的合理性
4. 一定要填約束：確保重要欄位不為空
5. 預設值：為部分欄位設定預設值，大部份允許免輸入的就預設NULL
