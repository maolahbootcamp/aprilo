-- librarySetup.sql
-- 小小小小型圖書館資料庫建立與資料插入指令

-- 1. 建立資料表（DDL）

-- ISBN資料庫
CREATE TABLE IF NOT EXISTS isbndata(
    isbn TEXT PRIMARY KEY,
    bname TEXT NOT NULL,    
    author TEXT DEFAULT NULL,
    publisher TEXT DEFAULT NULL,
    publish_year TEXT DEFAULT NULL,
    paperback INTEGER DEFAULT NULL,
    tags TEXT DEFAULT NULL,
    lang TEXT DEFAULT NULL,
    kind TEXT DEFAULT NULL,
    edition TEXT DEFAULT NULL,
    publisher_loc TEXT DEFAULT NULL
);

-- 書籍
CREATE TABLE IF NOT EXISTS books(
    bookid INTEGER PRIMARY KEY AUTOINCREMENT,
    isbn NOT NULL,
    price REAL NOT NULL CHECK(Price > 0),
    FOREIGN KEY (isbn) REFERENCES isbndata(isbn)
    );


-- 使用者
CREATE TABLE IF NOT EXISTS users(
    userid INTEGER PRIMARY KEY AUTOINCREMENT,
    identify TEXT DEFAULT NULL,
    uname TEXT NOT NULL,
    birthday TEXT DEFAULT NULL,
    phone TEXT DEFAULT NULL,
    email TEXT DEFAULT NULL,
    address TEXT DEFAULT NULL
);

-- 借閱記錄
CREATE TABLE IF NOT EXISTS rentrecord(
    rentid INTEGER PRIMARY KEY AUTOINCREMENT,
    bookid INTEGER NOT NULL,
    userid INTEGER NOT NULL,
    adate TEXT DEFAULT (datetime('now', 'localtime')),
    bdate TEXT DEFAULT NULL,
    rdate TEXT DEFAULT NULL,
    FOREIGN KEY (bookid) REFERENCES books(bookid),
    FOREIGN KEY (userid) REFERENCES users(userid)
);

-- 建立索引，提高查詢效能
CREATE INDEX IF NOT EXISTS idx_books_isbn ON books(isbn);
CREATE INDEX IF NOT EXISTS idx_users_identify ON users(identify);
CREATE INDEX IF NOT EXISTS idx_borrow_date ON rentrecord(bdate);

-- 2. 插入資料（DML）


-- 插入ISBN資料庫
INSERT INTO isbndata (bname,author,publisher,publish_year,isbn,paperback,tags,lang,kind,edition,publisher_loc) VALUES
('慢富 : 慢慢成為富一代, 快快過上自由生活 = Get rich slowly','慢活夫妻George & Dewi','遠流',2023,'9786263610002',279,'理財,投資','中文',563.5,'初版','臺北市'),
('一如既往 : 不變的人性法則與致富心態','豪瑟 , 周宜芳','遠見天下文化',2024,'9786263556379',319,'金錢心理學 , 理財','中文',561.014,'第一版','臺北市'),
('順著大腦來生活 : 從起床到就寢, 用大腦喜歡的模式, 活出創意、健康與生產力的最高生活法','蘿柯 , 黃庭敏','大牌',2022,'9786267102046',395,'腦部 , 科學 , 職場成功法','中文',394.911,'初版','新北市新店區'),
('當投資交易超越財務自由 : 進入富足自由喜悅的心境界','元睿','白象文化',2024,'9786263643895',221,'投資 , 理財 , 股票投資','中文',563.5,'初版','臺中市'),
('12個經濟指標 讓你投資無往不利 = Must-know economic indicators in the age of inflation','艾敏尤爾馬茲 , エミンユルマズ , 卓惠娟','遠見天下文化',2024,'9786263557482',239,'經濟指標 , 投資分析','中文',550.19,'第一版','臺北市'),
('寫給每個人的地球簡史 : 八堂四十億年的極簡地理課','諾爾 , 蔡承志','麥田',2023,'9786263105119',231,'地球科學','中文',350,'初版','臺北市'),
('化學家的科學講堂 : 從元素、人體到宇宙, 無所不在的化學定律','藤嶋昭 , 陳識中','臺灣東販',2022,'9786263296114',193,'化學 , 科學家','中文',340,'初版','臺北市'),
('大偵探福爾摩斯 : 文字與圖書 = Sherlock holmes',null,'匯識教育公司',2023,'9789887623205',128,'文字 , 科學','中文',308.9,null,'香港'),
('撼動華爾街的海龜交易員 : 從門外漢到頂尖交易者的傳奇故事 新手擊敗市場的11項鐵律法則','柯佛 , 呂佩憶','樂金文化',2024,'9786267321744',283,'投資分析 , 投資技術','中文',563.5,'初版','臺北市'),
('從人類飛出地球的那天開始 : 研發火箭、登月行動、前進宇宙、航太漫遊 這是一本人類至今的太空探索成果報告, 請過目!','張天蓉','崧燁文化',2023,'9786263576698',231,'太空科學 , 歷史 , 通俗作品','中文',326.09,'第一版','臺北市'),
('現在開始就有錢 : 改變一生的50個理財法則, 教你利用時間複利, 站上致富起跑點','楊比爾 , 楊書銘','遠流',2024,'9786263615595',295,'個人理財 , 投資','中文',563,'初版','臺北市'),
('超簡單買低賣高投資術 : 飆股、存股、ETF一次學會','孫慶龍','Smart智富',2023,'9786269743940',427,'股票投資 , 投資技術 , 投資分析','中文',563.53,'初版','臺北市'),
('植物大戰殭屍 : 恐龍漫畫 : 恐龍與魔術方塊','笑江南','南門',2021,'9789864917617',159,'科學 , 漫畫','中文',307.9,'初版','臺北市'),
('宇宙教我們的人生課 : 從無垠到剎那, 萬物蘊含的真理','泰森 , 邱佳皇','三采文化',2023,'9786263580725',335,'科學哲學 , 宇宙論','中文',163,null,'臺北市'),
('如果世界沒有力',null,'快樂文化',2023,'9786269621064',40,'科學 , 漫畫','中文',307.9,'初版','新北市新店區'),
('Python : 自動化股票網格交易實戰87個活用技巧 : 使用Python時作台股網格交易策略掌握自動化投資理財趨勢','劉承彥','博碩文化',2024,'9786263339231',201,'投資分析 , 金融投資工具 , Python(電腦程式語言)','中文',563.5029,'初版','新北市汐止區');

-- 插入書籍
INSERT INTO books(isbn,price) VALUES
('9786263610002',563.5),
('9786263556379',561.014),
('9786267102046',394.911),
('9786263643895',563.5),
('9786263557482',550.19),
('9786263105119',350),
('9786263296114',340),
('9789887623205',308.9),
('9786267321744',563.5),
('9786263576698',326.09),
('9786263615595',563),
('9786269743940',563.53),
('9789864917617',307.9),
('9786263580725',163),
('9786269621064',307.9),
('9786263339231',563.5029),
('9786263610002',563.5),
('9786263556379',561.014),
('9786267102046',394.911),
('9786263643895',563.5),
('9786263557482',550.19),
('9786263105119',350),
('9786263296114',340),
('9789887623205',308.9),
('9786267321744',563.5),
('9786263576698',326.09),
('9786263615595',563),
('9786269743940',563.53),
('9789864917617',307.9),
('9786263580725',163),
('9786269621064',307.9),
('9786263339231',563.5029);


-- 插入使用者
INSERT INTO users (identify,uname,birthday,phone,email,address) VALUES
('A158262310','Tony','1970/12/15','0980289563','cat@gmail.com','台北'),
('B199078674','John','1971/11/16','0956578654','dog@gmail.com','桃園'),
('C110246713','Mary','1972/10/17','0999142145','rabbit@gmail.com','新竹'),
('D144236133','Sandy','1973/9/18','0920454828','fish@gmail.com','苗栗'),
('E120490246','Debbie','1974/8/19','0984571524','man@gmail.com','台中'),
('F128923656','陳大金','1975/7/20','0976609929','woman@gmail.com','彰化'),
('A158262310','金小波','1976/6/21','0957847353','apple@gmail.com','南投'),
('B199078674','胡中仙','1977/5/22','0958043553','berry@gmail.com','高雄'),
('C110246713','張大千','1978/4/23','0982229798','zombie@gmail.com','花蓮'),
('D144236133','王大頭','1979/3/24','0985617821','plants@gmail.com','台東'),
('E120490246','米米克','1980/2/25','0936943284','pie@gmail.com','台南'),
('F128923656','福利連','1981/1/26','0928051819','python@gmail.com','雲林'),
('G185749594','很肥輪','1982/12/27','0948636624','java@gmail.com','嘉義'),
('H194982401','蘭花草','1983/11/28','0936063722','coffee@gmail.com','新竹'),
('J197941182','金山角','1984/10/1','0949375978','tension@gmail.com','苗栗'),
('K117083859','鐵三角','1985/9/2','0923297590','big@gmail.com','台中'),
('L166016025','Stella','1986/8/3','0975591453','small@gmail.com','彰化'),
('M190658483','vanilla','1987/7/4','0975447789','large@gmail.com','南投'),
('N174742974','mark','1988/6/5','0912749941','extra@gmail.com','高雄'),
('O142471098','susan','1989/5/6','0917862835','wide@gmail.com','花蓮'),
('P157943255','皇家祥','1990/4/7','0963307146','plane@gmail.com','台東');


-- 插入借閱記錄
INSERT INTO rentrecord (bookid,userid,bdate,rdate,adate) VALUES
(3,4,'2024/12/15','2024/12/21',NULL),
(20,19,'2024/11/16','2024/11/18',NULL),
(13,6,'2024/10/17','2024/10/20',NULL),
(12,9,'2024/9/18','2024/9/28',NULL),
(19,3,'2024/8/19','2024/8/19',NULL),
(18,19,'2024/7/20','2024/7/24',NULL),
(22,16,'2024/6/21','2024/6/25',NULL),
(29,7,'2024/5/22','2024/5/28',NULL),
(28,3,'2024/4/23','2024/4/30',NULL),
(8,7,'2024/3/24','2024/4/04',NULL),
(26,17,'2024/2/25','2024/3/15',NULL),
(6,1,'2024/1/26','2024/2/28',NULL),
(29,20,'2024/12/27','2025/01/12',NULL),
(25,12,'2024/11/28','2024/12/08',NULL),
(19,8,'2024/10/1','2024/10/17',NULL),
(1,21,'2024/9/2','2024/9/20',NULL),
(6,16,'2024/8/3','2024/8/13',NULL),
(22,7,'2024/7/4','2024/7/14',NULL),
(4,5,'2024/6/5','2024/6/25',NULL),
(1,3,'2024/5/6','2024/5/16',NULL),
(32,12,'2024/4/7','2024/4/9',NULL),
(10,12,'2024/10/1','2024/10/11',NULL);

-- 3. 查詢資料（DQL）

-- 查詢
-- 將結果輸出到BorrowCount_Result.md
.output BorrowCount_Result.md
-- 表格使用markdown 格式
.mode markdown
-- 開啟標頭
.header on

SELECT '## 使用者資訊';
SELECT * FROM users LIMIT 3;

SELECT '## 各本書的數量';
SELECT substr(bname,1,30) AS 書名,count(books.isbn) AS 數量 
FROM books LEFT JOIN isbndata ON books.isbn=isbndata.isbn GROUP BY books.isbn LIMIT 3;

SELECT '## 借閱記錄';
SELECT uname AS 使用者,substr(bname,1,30) AS 書名,bdate AS 借書日,rdate AS 還書日 FROM rentrecord LEFT JOIN users ON rentrecord.userid=users.userid LEFT JOIN books ON rentrecord.bookid=books.bookid LEFT JOIN isbndata ON books.isbn=isbndata.isbn LIMIT 3;

SELECT '## 借閱次數';
SELECT uname AS 使用者,substr(bname,1,30) AS 書名,count(bdate) AS 借閱次數 FROM rentrecord LEFT JOIN users ON rentrecord.userid=users.userid LEFT JOIN books ON rentrecord.bookid=books.bookid LEFT JOIN isbndata ON books.isbn=isbndata.isbn WHERE ((bdate NOT NULL) AND (rdate NOT NULL)) GROUP BY rentrecord.userid ORDER BY count(bdate) DESC LIMIT 3;

.output stdout
