

create table Book (
 Book_ID integer primary key,
 CategoryID text ,
 Title text ,
 Year integer,
 TotalCopies text,
 AvaliableCopies text,
 foreign key (CategoryID) references Category(CategoryID)
 );

create table Loan (
 LoanID integer primary key,
 Book_ID integer,
 MemberID integer,
 BorrowDate date,
 DueDate date,
 Relurn date,
foreign key (Book_ID) references Book (Book_ID),
foreign key (MemberID) references Member (MemberID)
);


create table Member (
MemberID integer primary key,
Name text ,
Phone integer,
Email text,
Address text,
Joindate date
);

create table Category (
CategoryID primary key,
CategoryIDName text
);

CREATE INDEX IF NOT EXISTS idx_Loan_BookID on Loan(Book_ID);
CREATE INDEX IF NOT EXISTS idx_Loan_BorrowDate on Loan(BorrowDate);

select * from idx_Loan_BookID

INSERT INTO Book (Book_ID, CategoryID, Title, Year, TotalCopies, AvaliableCopies) VALUES
(1, 'FIC', 'The Midnight Library', 2020, '10', '4'),
(2, 'SCI', 'A Brief History of Time', 1988, '7', '2'),
(3, 'BIO', 'Becoming', 2018, '5', '1'),
(4, 'HIS', 'Sapiens: A Brief History of Humankind', 2011, '8', '3'),
(5, 'FIC', 'The Night Circus', 2011, '6', '0'),
(6, 'TECH', 'Clean Code', 2008, '12', '7'),
(7, 'SCI', 'The Gene: An Intimate History', 2016, '9', '5'),
(8, 'FIC', 'Where the Crawdads Sing', 2018, '11', '6'),
(9, 'MYS', 'Gone Girl', 2012, '10', '2'),
(10, 'FIC', 'The Alchemist', 1988, '15', '9');

INSERT INTO Loan (LoanID, Book_ID, MemberID, BorrowDate, DueDate, Relurn) VALUES
(1, 3, 102, '2025-03-01', '2025-03-15', '2025-03-12'),
(2, 1, 107, '2025-03-05', '2025-03-19', '2025-03-17'),
(3, 5, 110, '2025-03-08', '2025-03-22', '2025-03-22'),
(4, 6, 105, '2025-03-10', '2025-03-24', NULL),
(5, 2, 101, '2025-03-12', '2025-03-26', '2025-03-25'),
(6, 8, 109, '2025-03-14', '2025-03-28', NULL),
(7, 4, 104, '2025-03-18', '2025-04-01', '2025-03-30'),
(8, 7, 103, '2025-03-20', '2025-04-03', NULL),
(9, 10, 106, '2025-03-22', '2025-04-05', '2025-04-04'),
(10, 9, 108, '2025-03-25', '2025-04-08', NULL);


INSERT INTO Member (MemberID, Name, Phone, Email, Address, Joindate) VALUES
(1, 'Alice Chen', 912345678, 'alice.chen@example.com', 'Taipei City, Taiwan', '2023-01-10'),
(2, 'Brian Lin', 913456789, 'brian.lin@example.com', 'Taichung City, Taiwan', '2023-02-15'),
(3, 'Cindy Wu', 914567890, 'cindy.wu@example.com', 'Tainan City, Taiwan', '2023-03-20'),
(4, 'David Huang', 915678901, 'david.huang@example.com', 'Kaohsiung City, Taiwan', '2023-04-05'),
(5, 'Emily Tsai', 916789012, 'emily.tsai@example.com', 'Hsinchu City, Taiwan', '2023-05-18'),
(6, 'Frank Yeh', 917890123, 'frank.yeh@example.com', 'Keelung City, Taiwan', '2023-06-22'),
(7, 'Grace Liu', 918901234, 'grace.liu@example.com', 'Chiayi City, Taiwan', '2023-07-30'),
(8, 'Henry Wang', 919012345, 'henry.wang@example.com', 'Yilan County, Taiwan', '2023-08-11'),
(9, 'Ivy Chang', 920123456, 'ivy.chang@example.com', 'Miaoli County, Taiwan', '2023-09-03'),
(10, 'Jason Lee', 921234567, 'jason.lee@example.com', 'Pingtung County, Taiwan', '2023-10-19');

INSERT INTO Category (CategoryID, CategoryIDName) VALUES
('FIC', 'Fiction'),
('SCI', 'Science'),
('BIO', 'Biography');







