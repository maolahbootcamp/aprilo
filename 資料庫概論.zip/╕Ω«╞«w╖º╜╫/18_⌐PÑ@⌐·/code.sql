CREATE TABLE User (
 user_id TEXT NOT NULL,
 user_name TEXT NOT NULL,
 user_phone INTEGER NOT NULL,
 PRIMARY KEY(user_id)
);


CREATE TABLE Books (
 ISBN INTEGER,
 book_name TEXT NOT NULL,
 author TEXT NOT NULL,
 publisher TEXT NOT NULL,
 type TEXT NOT NULL,
 PRIMARY KEY(ISBN)
);



CREATE TABLE Staff (
 stf_id INTEGER NOT NULL,
 stf_name TEXT NOT NULL,
 stf_phone TEXT DEFAULT '03-4567890',
 PRIMARY KEY(stf_id)
);


CREATE TABLE BorrowRecord (
 record_id INTEGER,
 book_id INTEGER NOT NULL,
 bor_name TEXT NOT NULL,
 bor_staff INTEGER NOT NULL,
 bor_date TEXT NOT NULL,
 bor_return_date TEXT,
 PRIMARY KEY(record_id),
 FOREIGN KEY(bor_name) REFERENCES User(user_id),
 FOREIGN KEY(bor_staff) REFERENCES Staff(stf_id),
 FOREIGN KEY(book_id) REFERENCES Books(ISBN)
);


INSERT INTO User VALUES
('b9688174', 'John', 0911222333),
('b9688175', 'Ben', 0944222333),
('b9688176', 'May', 0955222333),
('b9788174', 'Zoe', 0966882333);


INSERT INTO Staff VALUES(1, 'Cathy', '03-5468132');
INSERT INTO Staff(stf_id, stf_name) VALUES(2, 'Hen');
INSERT INTO Staff VALUES(3, 'Antony', '02-7539514');
INSERT INTO Staff(stf_name) VALUES('Lenny');
INSERT INTO Staff(stf_name) VALUES('Piggy');


INSERT INTO Books VALUES(1234567, 'Java應用', '陳小白', '基風出版社', '程式設計類');
INSERT INTO Books VALUES(3405762, '三國演義', '羅貫中', '金庸出版社', '武俠類');
INSERT INTO Books VALUES(88644699, 'SQL基礎', '艾莉絲', '基風出版社', '程式設計類');
INSERT INTO Books VALUES(2947687, 'Android程式設計', '鐵金剛', '基風出版社', '程式設計類');
INSERT INTO Books VALUES(53025067, '愛上霸道總裁', '王館長', '惡昭出版社', '文藝愛情類');
INSERT INTO Books VALUES(4866710, '貓空愛情故事', '藤井樹', '東版出版社', '散文類');
INSERT INTO Books VALUES(3876915, '拯救手機腦', '安德斯韓森', '老王出版社', '散文類');


ALTER TABLE Books ADD COLUMN quantity INTEGER;
UPDATE Books SET quantity = 3 WHERE ISBN = 1234567;
UPDATE Books SET quantity = 2 WHERE ISBN = 3405762;
UPDATE Books SET quantity = 4 WHERE ISBN = 88644699;
UPDATE Books SET quantity = 3 WHERE ISBN = 2947687;
UPDATE Books SET quantity = 2 WHERE ISBN = 53025067;
UPDATE Books SET quantity = 3 WHERE ISBN = 4866710;
UPDATE Books SET quantity = 1 WHERE ISBN = 3876915;


INSERT INTO BorrowRecord VALUES
(1, 2947687, 'b9688175', 4, '2023-12-22', '2024-01-02'),
(2, 4866710, 'b9788174', 1, '2023-11-03', '2024-01-22'),
(3, 2947687, 'b9788174', 4, '2023-07-14', '2024-06-06'),
(4, 53025067, 'b9688175', 3, '2023-12-22', NULL),
(5, 1234567, 'b9788174', 2, '2024-03-05', '2024-06-13'),
(6, 3876915, 'b9788174', 5, '2024-04-02', '2024-10-09'),
(7, 88644699, 'b9688175', 3, '2024-11-30', NULL),
(8, 2947687, 'b9788174', 1, '2025-02-03', '2025-04-30');



SELECT Books.book_name AS '書名', COUNT(*) AS "借閱次數" FROM BorrowRecord
JOIN Books ON BorrowRecord.book_id  = Books.ISBN
WHERE book_id = 2947687;

