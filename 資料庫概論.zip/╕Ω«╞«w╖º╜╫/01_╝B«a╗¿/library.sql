-- 創建會員資料表
CREATE TABLE Members(
		identity_id VARCHAR(20) PRIMARY KEY,    --身分證字號
		name  VARCHAR(50),						--姓名
		loan_date DATE,							--借閱日期
		return_date DATE,						--還書日期
		due_date DATE,							--截止日期
		phone VARCHAR(20)						--電話
);



-- 輸入會員資料
INSERT INTO Members VALUES ('D241212762', '周子瑜', '2025-04-14', null, '2025-04-21','0912335678');
INSERT INTO Members VALUES ('H226972476', '葉舒華', '2025-04-01', '2025-04-05', '2025-04-08','0938999881');
INSERT INTO Members VALUES ('A100719649', '周杰倫', '2025-04-07', null, '2025-04-14','0912345678');
INSERT INTO Members VALUES ('B183565068', '韋禮安', null, null, null,'0999999998');



SELECT * from Members


-- 創建書籍資料表
CREATE TABLE Books(
   		ISBN VARCHAR(20) PRIMARY KEY,			--書籍編碼
   		book_name VARCHAR(50),					--書名
   		category VARCHAR(20),					--類別
   		publisher VARCHAR(20),					--出版社
   		author VARCHAR(50),						--作者
   		form VARCHAR(10),						--書的形式
   		quantity VARCHAR(10)
);

-- 輸入書籍資料
INSERT INTO Books VALUES ('9789861371955', '被討厭的勇氣', '心理學', '究竟', '岸見一郎 古賀史健','ebook','10');
INSERT INTO Books VALUES ('9789861362496', '蔡康永的說話之道', '人際關係', '如何', '蔡康永','paper book','8');
INSERT INTO Books VALUES ('9789865102647', '別對每件事都有反應', '生活哲學', '悅知文化', '枡野俊明','paper book','6');

INSERT INTO Books VALUES 
('9789861372273', '被討厭的勇氣 二部曲完結篇：人生幸福的行動指南', '心理學', '究竟', '岸見一郎,古賀史健','ebook','10');

INSERT INTO Books VALUES 
('9789861372600', '為愛徬徨的勇氣：阿德勒的幸福方法論', '心理學', '究竟', '岸見一郎','ebook','10');

INSERT INTO Books VALUES 
('9786263350717', '底層邏輯：看清這個世界的底牌', '工作哲學', '時報出版', '劉潤','paper book','5');

INSERT INTO Books VALUES 
('9789865596934', '逆思維', '商業理財', '平安文化', '亞當．格蘭特','paper book','0');



UPDATE Books set  author = '岸見一郎,古賀史健' where book_name = '被討厭的勇氣';--改作者資料

SELECT * from Books


-- 創建預約書籍表
CREATE TABLE Reservation(
		identity_id VARCHAR(20),
		ISBN VARCHAR(20),
		book_name VARCHAR(50),
   		category VARCHAR(20),
   		PRIMARY KEY (identity_id, ISBN),
		FOREIGN KEY (identity_id) REFERENCES Members(identity_id),
		FOREIGN KEY (ISBN) REFERENCES Books(ISBN)
);

-- 輸入預約書籍資料
INSERT INTO Reservation VALUES ('B183565068','9789865596934', '逆思維', '商業理財');
ALTER TABLE Reservation ADD COLUMN reservation_date DATE;  --新增預約時間欄位

UPDATE Reservation
SET reservation_date = '2025-04-10'
WHERE identity_id = 'B183565068' AND ISBN = '9789865596934';--新增預約時間資料



SELECT * from Reservation


-- 創建借閱紀錄表
CREATE TABLE Loan(
		identity_id VARCHAR(20),  --身分證字號
		ISBN VARCHAR(20),         --書籍編號
		loan_date DATE,			  --借閱日期
		due_date DATE,			  --還書截止日期
		PRIMARY KEY (identity_id, ISBN),
		FOREIGN KEY (identity_id) REFERENCES Members(identity_id),
		FOREIGN KEY (ISBN) REFERENCES Books(ISBN)
);


-- 輸入借閱資料
INSERT INTO Loan VALUES ('D241212762','9789861371955', '2025-04-14', '2025-04-21');
INSERT INTO Loan VALUES ('A100719649','9789865102647', '2025-04-07', '2025-04-14');
INSERT INTO Loan VALUES ('H226972476','9789861362496', '2025-04-01', '2025-04-08');






SELECT * from Loan


--建立索引
CREATE INDEX idx_name ON Members(name);
CREATE INDEX idx_ISBN ON Books(ISBN);


SELECT * FROM Members WHERE name = '周子瑜';
SELECT * FROM Books WHERE ISBN = '9789861371955';


--查詢借閱資料
SELECT 
    Members.identity_id, 
    Members.name, 
    Books.ISBN, 
    Books.book_name, 
    Loan.loan_date, 
    Loan.due_date
FROM Loan
JOIN Members ON Loan.identity_id = Members.identity_id
JOIN Books ON Loan.ISBN = Books.ISBN;

--查詢預約資料
SELECT 
    Members.identity_id AS 身分證字號,
    Members.name AS 姓名,
    Books.ISBN AS 書籍編號,
    Books.book_name AS 書名,
    Reservation.reservation_date AS 預約時間
FROM Reservation
JOIN Members ON Reservation.identity_id = Members.identity_id
JOIN Books ON Reservation.ISBN = Books.ISBN;





