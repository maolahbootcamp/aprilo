

任務簡述：

假設我是一家小型圖書館的資料管理員，負責設計與建立一個簡單的書籍管理資料庫。

資料模型與正規化說明：



********************************* SQLite語法 *********************************

-- 圖書館借閱紀錄資料庫建立與資料插入指令

-- 1. 創建表格

-- 書籍資料表
create table BookInfo (
	isbn text,
	book_name text,
	barcode text primary key
);

-- 讀者資料表
create table UserInfo (
	user_id text primary key,
	user_name text,
	user_phone text,
	unique(user_name, user_phone)
);

-- 借閱紀錄表
create table BorrRec (
	barcode text,
	start_date date,
	re_date date,
	due_date date,
	user_id text,
	foreign key (barcode) references BookInfo(barcode),
	foreign key (user_id) references UserInfo(user_id)
);

-- 建立索引，提高查詢效能 

-- 1. 加速以讀者為條件的查詢（例如：查詢某位讀者借過哪些書）
create index idx_borrrec_user_id on BorrRec(user_id);

-- 2. 有助於查詢特定書籍目前是否被借出或已歸還
create index idx_borrrec_barcode on BorrRec(barcode);

-- 3. 有助於查找逾期或即將到期的書籍
create index idx_borrrec_due_date on BorrRec(due_date);

-- 4. 有助於追蹤實際歸還日期，特別是用於報表或逾期分析時
create index idx_borrrec_re_date on BorrRec(re_date);

-- 5. 便於篩選某讀者尚未歸還的借閱資料
create index idx_borrrec_user_re_date on BorrRec(user_id, re_date);

-- . 插入資料 (DML)

-- 插入書籍資料

INSERT INTO BookInfo (isbn, book_name, barcode) VALUES
('9789865025571', '3ds Max 2020 動畫設計快速入門', '0000001'),
('9786263243514', 'Excel終極函數辭典', '0000002'),
('9786263242661', '使用Python取代Excel VBA的10堂課', '0000003');

-- 插入讀者資料

insert into UserInfo (user_id, user_name, user_phone) values 
('U001', '王志明', '0963728190'),
('U002', '林春嬌', '0965347281'),
('U003', '高大帥', '0921836570');

--插入借閱紀錄

INSERT INTO BorrRec (barcode, start_date, re_date, due_date, user_id) VALUES
('0000002', '2025-04-01', NULL, '2025-05-01', 'U003'),
('0000003', '2025-03-27', '2025-04-25', '2025-04-10', 'U002'),
('0000001', '2025-04-01', '2025-04-30', '2025-04-10', 'U001'),
('0000002', '2025-04-02', NULL, '2025-05-16', 'U002'),
('0000003', '2025-04-03', '2025-05-02', '2025-04-14', 'U003');

-- 3. 查詢資料 (DQL)

-- 查詢書籍可否借閱

SELECT isbn, book_name, barcode 
FROM BookInfo 
WHERE book_name = '使用Python取代Excel VBA的10堂課' 
   OR isbn = '9786263242661';

--查詢讀者借閱書籍的到期日

SELECT B.barcode, B.due_date, U.user_name
FROM BorrRec B
JOIN UserInfo U ON B.user_id = U.user_id
WHERE U.user_name = '高大帥';

--查詢所有已逾期的書籍資訊 

SELECT 
    B.barcode, 
    BI.book_name, 
    U.user_name, 
    B.start_date, 
    B.due_date
FROM 
    BorrRec B
JOIN 
    BookInfo BI ON B.barcode = BI.barcode
JOIN                                           
    UserInfo U ON B.user_id = U.user_id
WHERE 
    B.re_date IS NULL 
    AND B.due_date < DATE('2025-05-01');

