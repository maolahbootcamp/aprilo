CREATE TABLE book (
    book_id INT PRIMARY KEY,  -- 書編號
    book_name VARCHAR(50),    -- 書名
    book_category VARCHAR(15), -- 類別
    book_author VARCHAR(50)   -- 作者
);

INSERT INTO book (book_id, book_name, book_category, book_author) VALUES
(1, '解憂雜貨店', '小說', '東野圭吾'),
(2, '被討厭的勇氣', '心理學', '岸見一郎、古賀史健'),
(3, '我輩是貓', '文學', '夏目漱石'),
(4, '雪國', '小說', '川端康成'),
(5, '人間失格', '文學', '太宰治');

INSERT INTO book (book_id, book_name, book_category, book_author) VALUES
(6, '人類簡史', '歷史', '尤瓦爾·赫拉利'),
(7, '解構哲學', '哲學', '蘇格拉底'),
(8, '快樂學', '心理學', '安東尼·羅賓'),
(9, '思想的歷史', '歷史', '羅伯特·貝爾'),
(10, '黑客與畫家', '科技', '保羅·格雷厄姆'),
(11, '平凡的世界', '文學', '路遙'),
(12, '局外人', '文學', '阿爾貝·加繆'),
(13, '明朝那些事兒', '歷史', '當年明月'),
(14, '天才的誕生', '自傳', '卡爾·賓特'),
(15, '聰明的投資者', '經濟', '本傑明·格雷厄姆'),
(16, '邏輯學導論', '哲學', '吉爾伯特·哈特曼'),
(17, '優雅的暴力', '社會學', '張曉峰'),
(18, '反脆弱', '哲學', '納西姆·尼古拉斯·塔勒布'),
(19, '藝術的故事', '藝術', '恩斯特·贡布里希'),
(20, '學會提問', '教育', '尼爾·布朗');


select *from book


CREATE TABLE member (
    member_id VARCHAR(10) PRIMARY KEY,  -- 會員編號
    member_name VARCHAR(50),    -- 會員名
    phone VARCHAR(15) -- 會員電話
);

INSERT INTO member (member_id, member_name, phone) VALUES
('A01', '張小明', '0912345678'),
('A02', '李雅婷', '0987654321'),
('A03', '王大華', '0922333445'),
('A04', '陳思涵', '0955443321'),
('A05', '林俊傑', '0933221100'),
('A06', '黃柏林', '0966112233'),
('A07', '劉雨婷', '0977554433'),
('A08', '周建宏', '0922445566'),
('A09', '徐佳慧', '0911888222'),
('A10', '蔡志明', '0944332211');

select *from member


CREATE TABLE record (
	record_id VARCHAR(10) PRIMARY KEY,  -- 記錄ID    
	member_id VARCHAR(10) ,  -- 會員編號
    borrowdate DATE,   --借閱日期
    returndate DATE   --還書日期
);

ALTER TABLE record ADD COLUMN book_id VARCHAR(10);



INSERT INTO record (record_id, member_id, borrowdate, returndate) VALUES
('R001', 'A101', '2025-04-01', '2025-04-15'),
('R002', 'A102', '2025-04-02', '2025-04-16'),
('R003', 'A103', '2025-04-03', '2025-04-17'),
('R004', 'A104', '2025-04-04', '2025-04-18'),
('R005', 'A105', '2025-04-05', '2025-04-19'),
('R006', 'A106', '2025-04-06', '2025-04-20'),
('R007', 'A107', '2025-04-07', '2025-04-21'),
('R008', 'A108', '2025-04-08', '2025-04-22'),
('R009', 'A109', '2025-04-09', '2025-04-23'),
('R010', 'A110', '2025-04-10', '2025-04-24'),
('R011', 'A101', '2025-04-11', '2025-04-25'),
('R012', 'A102', '2025-04-12', '2025-04-26'),
('R013', 'A103', '2025-04-13', '2025-04-27'),
('R014', 'A104', '2025-04-14', '2025-04-28'),
('R015', 'A105', '2025-04-15', '2025-04-29'),
('R016', 'A106', '2025-04-16', '2025-04-30'),
('R017', 'A107', '2025-04-17', '2025-05-01'),
('R018', 'A108', '2025-04-18', '2025-05-02'),
('R019', 'A109', '2025-04-19', '2025-05-03'),
('R020', 'A110', '2025-04-20', '2025-05-04');

INSERT INTO record (record_id, member_id, borrowdate, returndate, book_id) VALUES
('R021', 'A01', '2025-04-21', '2025-05-05', '10'), 
('R023', 'A03', '2025-04-23', '2025-05-07', '3'),  
('R024', 'A04', '2025-04-24', '2025-05-08', '14'),  
('R025', 'A05', '2025-04-25', '2025-05-09', '20');  

INSERT INTO record (record_id, member_id, borrowdate, returndate, book_id) VALUES
('R026', 'A03', '2025-04-28', '2025-05-07', '15');

UPDATE record SET book_id = '1' WHERE record_id = 'R001';
UPDATE record SET book_id = '2' WHERE record_id = 'R002';
UPDATE record SET book_id = '3' WHERE record_id = 'R003';
UPDATE record SET book_id = '4' WHERE record_id = 'R004';
UPDATE record SET book_id = '5' WHERE record_id = 'R005';
UPDATE record SET book_id = '6' WHERE record_id = 'R006';
UPDATE record SET book_id = '7' WHERE record_id = 'R007';
UPDATE record SET book_id = '8' WHERE record_id = 'R008';
UPDATE record SET book_id = '9' WHERE record_id = 'R009';
UPDATE record SET book_id = '10' WHERE record_id = 'R010';
UPDATE record SET book_id = '11' WHERE record_id = 'R011';
UPDATE record SET book_id = '12' WHERE record_id = 'R012';
UPDATE record SET book_id = '13' WHERE record_id = 'R013';
UPDATE record SET book_id = '14' WHERE record_id = 'R014';
UPDATE record SET book_id = '15' WHERE record_id = 'R015';
UPDATE record SET book_id = '16' WHERE record_id = 'R016';
UPDATE record SET book_id = '17' WHERE record_id = 'R017';
UPDATE record SET book_id = '18' WHERE record_id = 'R018';
UPDATE record SET book_id = '19' WHERE record_id = 'R019';
UPDATE record SET book_id = '20' WHERE record_id = 'R020';

UPDATE record SET member_id = 'A01' WHERE member_id = 'A101';
UPDATE record SET member_id = 'A02' WHERE member_id = 'A102';
UPDATE record SET member_id = 'A03' WHERE member_id = 'A103';
UPDATE record SET member_id = 'A04' WHERE member_id = 'A104';
UPDATE record SET member_id = 'A05' WHERE member_id = 'A105';
UPDATE record SET member_id = 'A06' WHERE member_id = 'A106';
UPDATE record SET member_id = 'A07' WHERE member_id = 'A107';
UPDATE record SET member_id = 'A08' WHERE member_id = 'A108';
UPDATE record SET member_id = 'A09' WHERE member_id = 'A109';
UPDATE record SET member_id = 'A10' WHERE member_id = 'A110';

select *from record


SELECT record.record_id, record.member_id, member.member_name, book.book_name ,record.borrowdate, record.returndate
FROM record
JOIN member ON record.member_id = member.member_id
JOIN book ON record.book_id = book.book_id
WHERE record.book_id = '10'; ---編號10這本書的借閱記錄









