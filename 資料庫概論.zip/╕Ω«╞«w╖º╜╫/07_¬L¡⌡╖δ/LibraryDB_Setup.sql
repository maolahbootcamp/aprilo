-- 創建借書者資料表
CREATE TABLE IF NOT EXISTS Lenders_Info (
    Lender_id INT PRIMARY KEY,
    Name VARCHAR(50)
);

-- 創建書本資料表
CREATE TABLE IF NOT EXISTS Call_Book_Number_Info(
	Call_Book_id INT PRIMARY KEY,
	Book_Name VARCHAR(50),
	ISBN VARCHAR(50),
	Genre VARCHAR(50), --分類
	publisher VARCHAR(50)
);

 -- 創建管理員資料表
CREATE TABLE IF NOT EXISTS Librarian_Info (
    Librarian_id INT PRIMARY KEY,
    Name VARCHAR(50)
);

 -- 創建借書資料表
CREATE TABLE IF NOT EXISTS Lending_Info(
	lending_proj_id INT ,
	Lending_day DATETIME DEFAULT CURRENT_TIMESTAMP,
	Lender_id INTEGER,
	Call_Book_id INTEGER,
	Librarian_id INTEGER,
	Return_day VARCHAR(50),
	PRIMARY KEY (Lender_id,Call_Book_id,Librarian_id),
	FOREIGN KEY (Lender_id) REFERENCES Lenders_Info(Lender_id),
	FOREIGN KEY (Call_Book_id) REFERENCES Call_Book_Number_Info(Call_Book_id),
	FOREIGN KEY (Librarian_id) REFERENCES Librarian_Info ( Librarian_id)
);

-- 插入 6 個 借書者
INSERT INTO Lenders_Info VALUES
    (1, 'Alice'),
    (2, 'Bob'),
    (3, 'Charlie'),
    (4, 'David'),
    (5, 'Eve');
INSERT INTO Lenders_Info VALUES
	(6, 'John');

--DELETE FROM Call_Book_Number_Info;
-- 插入 10 本每本重複3本 書籍資料
INSERT INTO Call_Book_Number_Info (Call_Book_id, Book_Name, ISBN, Genre, Publisher) VALUES
(1, 'To Kill a Mockingbird', '9780061120084', 'Fiction', 'Harper Perennial'),
(2, 'To Kill a Mockingbird', '9780061120084', 'Fiction', 'Harper Perennial'),
(3, 'To Kill a Mockingbird', '9780061120084', 'Fiction', 'Harper Perennial'),
(4, '1984', '9780451524935', 'Dystopian', 'Signet Classics'),
(5, '1984', '9780451524935', 'Dystopian', 'Signet Classics'),
(6, '1984', '9780451524935', 'Dystopian', 'Signet Classics'),
(7, 'The Great Gatsby', '9780743273565', 'Classic', 'Scribner'),
(8, 'The Great Gatsby', '9780743273565', 'Classic', 'Scribner'),
(9, 'The Great Gatsby', '9780743273565', 'Classic', 'Scribner'),
(10, 'A Brief History of Time', '9780553380163', 'Science', 'Bantam'),
(11, 'A Brief History of Time', '9780553380163', 'Science', 'Bantam'),
(12, 'A Brief History of Time', '9780553380163', 'Science', 'Bantam'),
(13, 'The Catcher in the Rye', '9780316769488', 'Fiction', 'Little Brown and Company'),
(14, 'The Catcher in the Rye', '9780316769488', 'Fiction', 'Little Brown and Company'),
(15, 'The Catcher in the Rye', '9780316769488', 'Fiction', 'Little Brown and Company'),
(16, 'Sapiens: A Brief History of Humankind', '9780062316097', 'History', 'Harper'),
(17, 'Sapiens: A Brief History of Humankind', '9780062316097', 'History', 'Harper'),
(18, 'Sapiens: A Brief History of Humankind', '9780062316097', 'History', 'Harper'),
(19, 'The Hobbit', '9780547928227', 'Fantasy', 'Mariner Books'),
(20, 'The Hobbit', '9780547928227', 'Fantasy', 'Mariner Books'),
(21, 'The Hobbit', '9780547928227', 'Fantasy', 'Mariner Books'),
(22, 'Harry Potter and the Sorcerer''s Stone', '9780590353427', 'Fantasy', 'Scholastic'),
(23, 'Harry Potter and the Sorcerer''s Stone', '9780590353427', 'Fantasy', 'Scholastic'),
(24, 'Harry Potter and the Sorcerer''s Stone', '9780590353427', 'Fantasy', 'Scholastic'),
(25, 'Pride and Prejudice', '9780141439518', 'Romance', 'Penguin Classics'),
(26, 'Pride and Prejudice', '9780141439518', 'Romance', 'Penguin Classics'),
(27, 'Pride and Prejudice', '9780141439518', 'Romance', 'Penguin Classics'),
(28, 'Thinking, Fast and Slow', '9780374533557', 'Psychology', 'Farrar Straus and Giroux'),
(29, 'Thinking, Fast and Slow', '9780374533557', 'Psychology', 'Farrar Straus and Giroux'),
(30, 'Thinking, Fast and Slow', '9780374533557', 'Psychology', 'Farrar Straus and Giroux');

-- 插入 3位 管理員
INSERT INTO Librarian_Info (Librarian_id, Name) VALUES
(1, '陳美玲'),
(2, '王志豪'),
(3, '林佳蓉');

-- 創建6筆借書資料表
INSERT INTO Lending_Info (lending_proj_id, Lending_day, Lender_id, Call_Book_id, Librarian_id) VALUES
(1, '2025-04-01', 1, 1, 1),
(2, '2025-04-02', 2, 2, 2),
(3, '2025-04-03', 3, 3, 3),
(4, '2025-04-04', 4, 4, 1),
(5, '2025-04-05', 5, 5, 2),
(6, '2025-04-06', 6, 6, 3);

-- 3. 查詢資料（DQL）
SELECT Lenders_Info.Name AS 借書人,
	   Call_Book_Number_Info.Book_Name As 書名, 
       Lending_Info.Lending_day AS 借書日
FROM Call_Book_Number_Info
JOIN Lending_Info ON  Call_Book_Number_Info.Call_Book_id = Lending_Info.Call_Book_id
JOIN Lenders_Info ON Lending_Info.Lender_id = Lenders_Info.Lender_id
where Call_Book_Number_Info.Book_Name =  "To Kill a Mockingbird";

/*
SELECT Lenders_Info.Name AS 借書人,
	   Call_Book_Number_Info.Book_Name As 書名, 
       Lending_Info.Lending_day AS 借書日,
       Call_Book_Number_Info.Genre AS 分類
FROM Lenders_Info
JOIN Lending_Info ON Lenders_Info.Lender_id = Lending_Info.Lender_id
JOIN Call_Book_Number_Info ON Lending_Info.Call_Book_id = Call_Book_Number_Info.Call_Book_id
where 書名 =  "To Kill a Mockingbird";
*/
SELECT Call_Book_Number_Info.Book_Name AS 書名,
       COUNT(Lending_Info.Call_Book_id) AS 被借閱次數
FROM Call_Book_Number_Info
LEFT JOIN Lending_Info ON Call_Book_Number_Info.Call_Book_id = Lending_Info.Call_Book_id
GROUP BY Call_Book_Number_Info.Book_Name;

--查詢"每個人"返回借閱次數結果
SELECT 
    Lenders_Info.Name AS 借閱者姓名,
    COUNT(Lending_Info.Lending_day) AS 借閱次數
FROM 
    Lenders_Info
LEFT JOIN 
    Lending_Info  ON Lenders_Info.Lender_id = Lending_Info.Lender_id
GROUP BY 
    Lenders_Info.Lender_id;

--查詢"可借閱"數結果
SELECT Call_Book_Number_Info.Book_Name AS 書名,
	  IFNULL(count(Call_Book_Number_Info.Book_Name = 'none'), 0) AS 書總數量,
	  COUNT(Lending_Info.Call_Book_id) AS 被借閱次數,
	  IFNULL(count(Call_Book_Number_Info.Book_Name = 'none'), 0)- COUNT(Lending_Info.Call_Book_id) AS 可借閱數量
FROM Call_Book_Number_Info
LEFT JOIN Lending_Info ON Call_Book_Number_Info.Call_Book_id = Lending_Info.Call_Book_id
GROUP BY Call_Book_Number_Info.Book_Name;