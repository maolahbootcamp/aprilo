﻿-- 類別表：CATEGORY
CREATE TABLE Category (
    CategoryID   TEXT PRIMARY KEY,
    CategoryName TEXT NOT NULL
);

-- 書籍表：BOOK
CREATE TABLE Book (
    BookID         TEXT PRIMARY KEY,
    Title          TEXT NOT NULL,
    Author         TEXT,
    ISBN           TEXT UNIQUE,
    Publisher      TEXT,
    Year           INTEGER,
    CategoryID     TEXT,
    TotalCopies    INTEGER DEFAULT 0,
    AvailableCopies INTEGER DEFAULT 0,
    BorrowCount    INTEGER DEFAULT 0,
    FOREIGN KEY (CategoryID) REFERENCES Category(CategoryID)
        ON DELETE SET NULL
);

-- 會員表：MEMBER
CREATE TABLE Member (
    MemberID  TEXT PRIMARY KEY,
    Name      TEXT NOT NULL,
    Phone     TEXT,
    Email     TEXT,
    Address   TEXT,
    JoinDate  DATE
);

-- 借閱紀錄表：LOAN
CREATE TABLE Loan (
    LoanID      TEXT PRIMARY KEY,
    BookID      TEXT,
    MemberID    TEXT,
    BorrowDate  DATE,
    DueDate     DATE,
    ReturnDate  DATE,
    FOREIGN KEY (BookID) REFERENCES Book(BookID)
        ON DELETE SET NULL,
    FOREIGN KEY (MemberID) REFERENCES Member(MemberID)
        ON DELETE SET NULL
);

-- 書籍操作紀錄表：BOOK_RECORD
CREATE TABLE Book_Record (
    RecordID    TEXT PRIMARY KEY,
    BookID      TEXT,
    MemberID    TEXT,
    ActionDate  DATE,
    ActionType  TEXT CHECK(ActionType IN ('借出', '歸還')),
    Notes       TEXT,
    FOREIGN KEY (BookID) REFERENCES Book(BookID)
        ON DELETE SET NULL,
    FOREIGN KEY (MemberID) REFERENCES Member(MemberID)
        ON DELETE SET NULL
);


--建立5個書目資料
INSERT INTO Category (CategoryID, CategoryName) VALUES
('C01', '小說'),
('C02', '歷史'),
('C03', '科學'),
('C04', '藝術'),
('C05', '心理學');

--建立30筆書籍資料
INSERT INTO Book (BookID, Title, Author, ISBN, Publisher, Year, CategoryID, TotalCopies, AvailableCopies, BorrowCount) VALUES
('B001', '解憂雜貨店', '東野圭吾', '9789861793673', '皇冠', 2013, 'C01', 5, 4, 1),
('B002', '嫌疑犯X的獻身', '東野圭吾', '9789861731965', '春天出版', 2006, 'C01', 4, 4, 0),
('B003', '人間失格', '太宰治', '9789861737882', '遠流', 2009, 'C01', 5, 4, 1),
('B004', '小王子', '安東尼·聖修伯里', '9789573317241', '遠流', 2005, 'C01', 5, 5, 0),
('B005', '白夜行', '東野圭吾', '9789861738452', '皇冠', 2010, 'C01', 4, 3, 1),
('B006', '活著', '余華', '9789573319078', '新經典', 2011, 'C01', 4, 4, 0),
('B007', '史記', '司馬遷', '9789570817393', '三民書局', 2000, 'C02', 4, 4, 0),
('B008', '中國大歷史', '黃仁宇', '9789573263838', '時報出版', 1997, 'C02', 3, 3, 0),
('B009', '資治通鑑', '司馬光', '9789570817867', '三民書局', 2001, 'C02', 3, 2, 1),
('B010', '萬曆十五年', '黃仁宇', '9789570814583', '聯經出版', 1982, 'C02', 4, 4, 0),
('B011', '秦始皇', '李開元', '9789863446607', '八旗文化', 2018, 'C02', 4, 3, 1),
('B012', '明朝那些事兒', '當年明月', '9789862164571', '三民書局', 2012, 'C02', 4, 4, 0),
('B013', '時間簡史', '霍金', '9789573317243', '天下文化', 1988, 'C03', 5, 5, 0),
('B014', '宇宙的結構', '布萊恩·葛林', '9789573318820', '天下文化', 2005, 'C03', 5, 4, 1),
('B015', '從一而終的宇宙', '李傑', '9789573273891', '台灣商務', 2012, 'C03', 4, 4, 0),
('B016', '萬物簡史', '比爾·布萊森', '9789573275154', '大塊文化', 2003, 'C03', 4, 4, 0),
('B017', '生命的演化', '道金斯', '9789861737455', '時報出版', 2007, 'C03', 3, 2, 1),
('B018', '基因傳', '悉達多·穆克吉', '9789863209653', '天下文化', 2016, 'C03', 3, 3, 0),
('B019', '藝術的故事', '贡布里希', '9789570801899', '聯經出版', 2001, 'C04', 4, 4, 0),
('B020', '設計中的設計', '原研哉', '9789867884078', '遠流', 2003, 'C04', 4, 3, 1),
('B021', '流行的力量', '馬爾科姆·葛拉威爾', '9789862413723', '商周出版', 2010, 'C04', 3, 3, 0),
('B022', '漫畫美術史', '山下裕二', '9789861341706', '大塊文化', 2006, 'C04', 4, 4, 0),
('B023', '攝影的藝術', '安斯·亞當斯', '9789571356009', '台灣攝影', 1998, 'C04', 3, 3, 0),
('B024', '建築的故事', '羅伯特·麥可卡特', '9789571357129', '藝術家出版社', 2011, 'C04', 4, 4, 0),
('B025', '被討厭的勇氣', '岸見一郎', '9789863208458', '遠流', 2013, 'C05', 5, 5, 0),
('B026', '情緒勒索', '周慕姿', '9789864775171', '遠流', 2016, 'C05', 4, 4, 0),
('B027', '原子習慣', '詹姆斯·克利爾', '9789864796671', '方智出版', 2019, 'C05', 5, 4, 1),
('B028', '內在原力', '楊斯棓', '9789864778516', '究竟出版', 2020, 'C05', 4, 4, 0),
('B029', '不便利的便利店', '金浩然', '9789861338881', '時報出版', 2021, 'C05', 4, 4, 0),
('B030', '深度工作力', '卡爾·紐波特', '9789864893073', '商周出版', 2018, 'C05', 4, 4, 0);

--建立10位會員
INSERT INTO Member (MemberID, Name, Phone, Email, Address, JoinDate) VALUES
('M01', '周杰倫', '0912345678', 'jay@example.com', '台北市音樂街1號', '2023-03-01'),
('M02', '蔡依林', '0922333444', 'jolin@example.com', '台北市舞蹈路2號', '2023-04-15'),
('M03', '林俊傑', '0933444555', 'jj@example.com', '新北市光明巷3號', '2023-05-10'),
('M04', '張惠妹', '0944555666', 'amei@example.com', '台東縣歌后村4號', '2023-06-20'),
('M05', '羅志祥', '0955666777', 'show@example.com', '高雄市帥哥街5號', '2023-07-25'),
('M06', '田馥甄', '0966777888', 'hebe@example.com', '新竹市東區6號', '2023-08-12'),
('M07', '張學友', '0977888999', 'jacky@example.com', '台中市經典路7號', '2023-09-08'),
('M08', '蕭敬騰', '0988999000', 'jam@example.com', '基隆市雨神巷8號', '2023-10-01'),
('M09', '陳綺貞', '0990001111', 'cheer@example.com', '花蓮市文青街9號', '2023-11-14'),
('M10', '楊丞琳', '0900111222', 'rainie@example.com', '台南市甜心路10號', '2023-12-02');

--建立10筆書籍借閱資料
INSERT INTO Loan (LoanID, BookID, MemberID, BorrowDate, DueDate, ReturnDate) VALUES
('L01', 'B001', 'M01', '2024-03-01', '2024-03-15', '2024-03-14'),
('L02', 'B005', 'M01', '2024-03-20', '2024-04-03', NULL),
('L03', 'B003', 'M01', '2024-04-01', '2024-04-15', NULL),
('L04', 'B011', 'M04', '2024-03-25', '2024-04-08', '2024-04-07'),
('L05', 'B009', 'M04', '2024-04-01', '2024-04-15', NULL),
('L06', 'B014', 'M02', '2024-03-18', '2024-04-01', '2024-03-30'),
('L07', 'B027', 'M02', '2024-04-03', '2024-04-17', NULL),
('L08', 'B017', 'M03', '2024-03-05', '2024-03-19', '2024-03-18'),
('L09', 'B020', 'M03', '2024-04-01', '2024-04-15', NULL),
('L10', 'B030', 'M01', '2024-04-05', '2024-04-19', NULL);

--建立20筆書籍借閱流水紀錄
INSERT INTO Book_Record (RecordID, BookID, MemberID, ActionDate, ActionType, Notes) VALUES
('R001', 'B001', 'M01', '2024-03-01', '借出', '首次借閱'),
('R002', 'B001', 'M01', '2024-03-14', '歸還', '提前歸還'),
('R003', 'B005', 'M01', '2024-03-20', '借出', '熱門書籍'),
('R004', 'B003', 'M01', '2024-04-01', '借出', '無備註'),
('R005', 'B030', 'M01', '2024-04-05', '借出', '無備註'),
('R006', 'B011', 'M04', '2024-03-25', '借出', '無備註'),
('R007', 'B011', 'M04', '2024-04-07', '歸還', '準時歸還'),
('R008', 'B009', 'M04', '2024-04-01', '借出', '無備註'),
('R009', 'B014', 'M02', '2024-03-18', '借出', '無備註'),
('R010', 'B014', 'M02', '2024-03-30', '歸還', '提前歸還'),
('R011', 'B027', 'M02', '2024-04-03', '借出', '無備註'),
('R012', 'B017', 'M03', '2024-03-05', '借出', '熱門書籍'),
('R013', 'B017', 'M03', '2024-03-18', '歸還', '準時歸還'),
('R014', 'B020', 'M03', '2024-04-01', '借出', '無備註'),
('R015', 'B018', 'M01', '2024-04-08', '借出', '無備註'),
('R016', 'B018', 'M01', '2024-04-18', '歸還', '準時歸還'),
('R017', 'B004', 'M01', '2024-04-20', '借出', '無備註'),
('R018', 'B004', 'M01', '2024-04-30', '歸還', '準時歸還'),
('R019', 'B027', 'M02', '2024-04-20', '歸還', '準時歸還'),
('R020', 'B020', 'M03', '2024-04-14', '歸還', '準時歸還');

--查詢周杰倫的借閱
SELECT 
    Loan.LoanID,
    Member.Name AS 會員姓名,
    Book.Title AS 書名,
    Loan.BorrowDate AS 借出日期,
    Loan.DueDate AS 到期日,
    Loan.ReturnDate AS 歸還日
FROM 
    Loan
JOIN Member ON Loan.MemberID = Member.MemberID
JOIN Book ON Loan.BookID = Book.BookID
WHERE 
    Member.Name = '周杰倫';

--查詢「秦始皇」這本書的借閱紀錄
SELECT 
    Loan.LoanID,
    Book.Title AS 書名,
    Member.Name AS 借閱者,
    Loan.BorrowDate AS 借出日期,
    Loan.DueDate AS 到期日,
    Loan.ReturnDate AS 歸還日
FROM 
    Loan
JOIN Member ON Loan.MemberID = Member.MemberID
JOIN Book ON Loan.BookID = Book.BookID
WHERE 
    Book.Title = '秦始皇';