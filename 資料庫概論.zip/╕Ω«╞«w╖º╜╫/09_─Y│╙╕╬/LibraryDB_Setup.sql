
-- 創建 Authors 作者表格 (T1)
CREATE TABLE Authors (
    author_id INTEGER PRIMARY KEY,
    name TEXT,
    nationality TEXT
);

-- 插入 3筆 Authors 作者資料 (T1)
INSERT INTO Authors VALUES
(1, '村上春樹', '日本'),
(2, 'J.K. 羅琳', '英國'),
(3, '喬治·歐威爾', '英國');


-- 創建 Categories 分類表格 (T2)
CREATE TABLE Categories (
    category_id INTEGER PRIMARY KEY,
    name TEXT
);

-- 插入 4筆 Categories 分類資料 (T2)
INSERT INTO Categories (category_id, name) VALUES
(1, '小說'),
(2, '奇幻'),
(3, '科幻'),
(4, '歷史');


-- 創建 Books 書籍表格 (T3)
CREATE TABLE Books (
    book_id INTEGER PRIMARY KEY,
    title TEXT,
    author_id INTEGER,
    category_id INTEGER,
    isbn TEXT,
    publication_year INTEGER,
    total_copies INTEGER,
    available_copies INTEGER,
    FOREIGN KEY (author_id) REFERENCES Authors(author_id),
    FOREIGN KEY (category_id) REFERENCES Categories(category_id)
);

-- 插入 10筆 Books 書籍資料 (T3)
INSERT INTO Books VALUES
(1, '挪威的森林', 1, 1, '9789573317241', 1987, 5, 1),
(2, '哈利波特與魔法石', 2, 2, '9789573317586', 1997, 10, 8),
(3, '1984', 3, 3, '9780451524935', 1949, 4, 0),
(4, '五分之一的奇蹟', 1, 3, '9789573321453', 1999, 3, 3),
(5, '老人與海', 2, 2, '9780684801223', 1952, 6, 6),
(6, '傲慢與偏見', 3, 1, '9780141439518', 1813, 5, 5),
(7, '湯姆歷險記', 1, 4, '9780141321097', 1876, 4, 4),
(8, '解憂雜貨店', 2, 4, '9789573331582', 2012, 7, 7),
(9, '魔戒', 3, 4, '9780261103573', 1954, 8, 8),
(10, '變形記', 1, 1, '9780141182537', 1915, 3, 3);

-- 創建 Members 會員名冊表格 (T4)
CREATE TABLE Members (
    member_id INTEGER PRIMARY KEY,
    name TEXT,
    email TEXT,
    phone TEXT,
    join_date TEXT
);

-- 插入 3筆 Members 會員名冊資料 (T4)
INSERT INTO Members VALUES
(1, '張小明', 'xiaoming@gmail.com', '0912345678', '2023-01-15'),
(2, '林美麗', 'meili@yahoo.com', '0923456789', '2023-02-20'),
(3, '王大偉', 'dawei@outlook.com', '0934567890', '2023-03-10');


-- 創建 CounterStaff 櫃檯職員表格 (T5)
CREATE TABLE CounterStaff (
    staff_id INTEGER PRIMARY KEY,
    name TEXT,
    email TEXT,
    phone TEXT,
    hire_date TEXT
);

-- 插入 2筆 CounterStaff 櫃檯職員資料 (T5)
INSERT INTO CounterStaff VALUES
(1, '陳麗華', 'lihua@library.com', '0911223344', '2022-01-10'),
(2, '林志遠', 'zhiyuan@library.com', '0922334455', '2022-02-15');


-- 創建 Borrowings 借閱紀錄表格 (T6)
CREATE TABLE Borrowings (
    borrowing_id INTEGER PRIMARY KEY,
    book_id INTEGER,
    member_id INTEGER,
    borrow_date TEXT,
    due_date TEXT,
    return_date TEXT DEFAULT 0,
    staff_handled INTEGER,
    FOREIGN KEY (book_id) REFERENCES Books(book_id),
    FOREIGN KEY (member_id) REFERENCES Members(member_id),
    FOREIGN KEY (staff_handled) REFERENCES CounterStaff(staff_id)
);

-- 插入 10筆 Borrowings 借閱紀錄資料 (T6)
INSERT INTO Borrowings VALUES
(1, 1, 1, '2025-03-01', '2025-03-15', '2025-03-10', 1),
(2, 2, 2, '2025-03-02', '2025-03-16', '0', 2),
(3, 3, 3, '2025-03-03', '2025-03-17', '2025-03-12', 1),
(4, 3, 2, '2025-03-04', '2025-03-18', '0', 2),
(5, 1, 3, '2025-03-05', '2025-03-19', '2025-03-15', 1),
(6, 1, 1, '2025-03-06', '2025-03-20', '0', 2),
(7, 2, 1, '2025-03-07', '2025-03-21', '2025-03-16', 1),
(8, 3, 3, '2025-03-08', '2025-03-22', '0', 2),
(9, 3, 2, '2025-03-09', '2025-03-23', '2025-03-18', 1),
(10, 1, 2, '2025-03-10', '2025-03-24', '0', 2);


-- 創建 Reservations 預約紀錄表格 (T7)
CREATE TABLE Reservations (
    reservation_id INTEGER PRIMARY KEY,
    book_id INTEGER,
    member_id INTEGER,
    reservation_date TEXT,
    reservation_status TEXT CHECK(reservation_status IN ('等待中', '已取消', '已完成')),
    notification_date TEXT DEFAULT NULL,
    staff_handled INTEGER,
    FOREIGN KEY (book_id) REFERENCES Books(book_id),
    FOREIGN KEY (member_id) REFERENCES Members(member_id)
    FOREIGN KEY (staff_handled) REFERENCES CounterStaff(staff_id)
);

-- 插入 3筆 Reservations 預約紀錄資料 (T7)
INSERT INTO Reservations VALUES
(1, 1, 1, '2025-03-01', '已完成', 2025-03-05, 1),
(2, 2, 2, '2025-03-02', '已取消', '2025-03-04', 2),
(3, 3, 3, '2025-03-03', '等待中', 'NULL', 1);


-- 任務一 : 查詢所有圖書及其作者,分類和當前可借數量：
-- 1-1更新Books(現行可借數量),透過"總數量"與"被借數量"相減差值(where篩選'借閱紀錄'與'圖書'表格中相同的book_id且借閱紀錄show沒還)
UPDATE Books
SET available_copies = total_copies - (
    SELECT COUNT(*)
    FROM Borrowings
    WHERE Borrowings.book_id = Books.book_id
    AND Borrowings.return_date = '0'
);

-- 1-2 於Books表加入新增欄位 br_no (該書被借次數)
ALTER TABLE Books ADD COLUMN br_no INTEGER;
UPDATE Books
SET br_no = (
    SELECT COUNT(*)
    FROM Borrowings
    WHERE Borrowings.book_id = Books.book_id
);

-- 1-3 查詢所有圖書及其作者,分類和當前可借數量 總表：
SELECT b.book_id AS 排序, b.title AS 書名, a.name AS 作者, c.name AS 分類, b.available_copies AS 當前可借數量, b.br_no AS 該書被借次數
FROM Books b
JOIN Authors a ON b.author_id = a.author_id
JOIN Categories c ON b.category_id = c.category_id;

-- 任務二 : 查詢 單一會員 張小明 的借閱次數 (=書已還+書未還)
SELECT 
    m.name AS 會員名, 
    COUNT(b.borrowing_id) AS 借閱次數, 
    (SELECT COUNT(*) 
     FROM Borrowings br 
     WHERE br.member_id = m.member_id 
     AND br.return_date = '0') AS 借閱未還次數
FROM Members m
JOIN Borrowings b ON m.member_id = b.member_id
WHERE m.name = '張小明';


-- 任務三 : 查詢 單一會員 張小明 的借閱詳細記錄：
SELECT m.name AS 會員名, b.title AS 書名, br.borrow_date AS 借閱時間, br.due_date AS 借閱到期日, br.return_date AS 已歸還日
FROM Borrowings br
JOIN Members m ON br.member_id = m.member_id
JOIN Books b ON br.book_id = b.book_id
WHERE m.name = '張小明';


：
