-- LibraryDB_Setup
-- 圖書館網站資料庫建立與資料插入指令
--資料庫引擎採用SQLLite

-- 1. 建立資料表（DDL）

----------------------------------------------------------------------------------------------------------------------------------------------------
-- 借閱主檔資料表
CREATE TABLE IF NOT EXISTS BorrowRecords(
	borr_id INTEGER NOT NULL UNIQUE PRIMARY KEY AUTOINCREMENT,
	user_id INTEGER NOT NULL,
	bookinfo_id INTEGER NOT NULL,
	borr_status INTEGER NOT NULL,-- 借閱狀態ID
	borr_start DATE NOT NULL,
	borr_end DATE,
	borr_Qty INT NOT NULL CHECK(borr_Qty <> 0),
	employee_id INT NOT NULL,
	FOREIGN KEY (user_id) REFERENCES User(user_id), -- 使用者ID
	FOREIGN KEY (bookinfo_id) REFERENCES Books(bookinfo_id), -- 書籍ID
	FOREIGN KEY (borr_status) REFERENCES BorrowStatus(borr_status_id), -- 借閱狀態ID
	FOREIGN KEY (employee_id) REFERENCES Employee(employee_id) -- 僱員ID
);
----------------------------------------------------------------------------------------------------------------------------------------------------

--借閱狀態
CREATE TABLE IF NOT EXISTS BorrowStatus(
	borr_status_id INTEGER PRIMARY KEY AUTOINCREMENT,
	borr_status_name TEXT NOT NULL UNIQUE,
	borr_status_desc TEXT NOT NULL
    penalty_id INTEGER NOT NULL DEFAULT 0 CHECK (penalty_id>0), -- 罰則ID
    FOREIGN KEY (penalty_id) REFERENCES Penalty(penalty_id) -- 罰則ID
);

--罰則
CREATE TABLE IF NOT EXISTS Penalty(
	penalty_id INTEGER PRIMARY KEY AUTOINCREMENT,
	penalty_name TEXT NOT NULL UNIQUE,
	penalty_amount INTEGER NOT NULL CHECK (penalty_amount>0)
);

----------------------------------------------------------------------------------------------------------------------------------------------------
--使用者
CREATE TABLE IF NOT EXISTS User(
	user_id INTEGER PRIMARY KEY AUTOINCREMENT,
	user_id_number TEXT NOT NULL UNIQUE, --使用者身份證號
	user_name TEXT NOT NULL,
	user_gender BIT NOT NULL DEFAULT 0 CHECK(user_gender==0 OR user_gender==1), -- 0:女,1:男 
	user_brithday DATE NOT NULL CHECK ((datetime('now', 'localtime')-user_brithday)>=18 AND (datetime('now', 'localtime')-user_brithday)<=72), --年齡限制18~72歲
	user_phone TEXT,
	user_email TEXT,
	user_address TEXT,
	user_current_time TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
	user_status INT NOT NULL DEFAULT 1 CHECK (user_status==1 OR user_status==0) -- 1:正常,0:停權
);

----------------------------------------------------------------------------------------------------------------------------------------------------
--僱員
CREATE TABLE IF NOT EXISTS Employee(
	employee_id INTEGER PRIMARY KEY AUTOINCREMENT,
	employeegrade_id INTEGER NOT NULL DEFAULT 0, --職位職級ID
	employee_id_number TEXT NOT NULL UNIQUE, --僱員身份證號
	employee_password TEXT NOT NULL CHECK (length(employee_password)>5), --僱員密碼
	employee_name TEXT NOT NULL, --僱員姓名
	employee_gender BIT NOT NULL DEFAULT 0, -- 0:女,1:男
	employee_brithday DATE NOT NULL, --僱員生日
	employee_contact TEXT, --聯絡電話
	employee_address TEXT, --聯絡地址
	employee_status BIT NOT NULL DEFAULT 1 CHECK (employee_status==1 OR employee_status==0), -- 1:正常,0:停權
	FOREIGN KEY (employeegrade_id) REFERENCES EmployeeGrade(employeegrade_id) --職位職級ID
);

--僱員職位職級
CREATE TABLE IF NOT EXISTS EmployeeGrade(
	employeegrade_id INTEGER PRIMARY KEY AUTOINCREMENT,
	employeegrade_title TEXT NOT NULL DEFAULT '兼職' CHECK(employeegrade_title IN('兼職','組長','科長')), --職位職級名稱
	employeegrade_leavel INTEGER NOT NULL CHECK (employeegrade_leavel>=0 AND employeegrade_leavel<=9) , --職位職級
	emplayeegrade_salary INTEGER DEFAULT 26000 CHECK (emplayeegrade_salary>=26000), --職位職級最低薪資
	emplayeegrade_trendy INTEGER DEFAULT 196 CHECK (emplayeegrade_trendy>=196) --職位職級最低時薪
);

--僱員出勤紀錄
CREATE TABLE IF NOT EXISTS Attendance(
	attendance_id INTEGER PRIMARY KEY AUTOINCREMENT, --出勤紀錄ID
	employee_id INTEGER NOT NULL, --僱員ID
	attendance_date DATE NOT NULL,
	attendance_time TIME NOT NULL,
	attendance_status TEXT NOT NULL CHECK (attendance_status IN ('上班','下班')),
	attendance_desc TEXT --出勤紀錄描述
	FOREIGN KEY (employee_id) REFERENCES Employee(employee_id) --僱員ID
);

----------------------------------------------------------------------------------------------------------------------------------------------------
--書籍主檔
CREATE TABLE IF NOT EXISTS BookInfo(
	bookinfo_id INTEGER PRIMARY KEY AUTOINCREMENT,
	bookinfo_ISBN TEXT NOT NULL,--書籍ISBN
	bookinfo_title TEXT NOT NULL, --書籍名稱
	publisher_id INTEGER NOT NULL CHECK (publisher_id>0),	--出版社ID
	author_id INTEGER NOT NULL CHECK (author_id>0), --作者ID
	bookclass_id INTEGER NOT NULL CHECK (bookclass_id>0), --書籍分類ID
	bookinfo_publication TEXT NOT NULL, --書籍出版日期
	FOREIGN KEY (publisher_id) REFERENCES Publisher(publisher_id), --出版社ID
	FOREIGN KEY (author_id) REFERENCES Author(author_id), --作者ID
	FOREIGN KEY (bookclass_id) REFERENCES BookClass(bookclass_id) --書籍分類ID
);

--書籍入庫紀錄
CREATE TABLE IF NOT EXISTS Books(
	books_id INTEGER PRIMARY KEY AUTOINCREMENT,
	bookinfo_id INTEGER NOT NULL, --書籍資訊ID
	books_entry INTEGER NOT NULL DEFAULT 1,--書籍入庫數量
	books_current_time TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),--書籍入庫時間
	books_status INTEGER NOT NULL DEFAULT 1, --書籍狀態 1:正常,0:停權
	FOREIGN KEY (bookinfo_id) REFERENCES BookInfo(bookinfo_id) --書籍資訊ID
);

--出版社
CREATE TABLE IF NOT EXISTS Publisher(
	publisher_id INTEGER PRIMARY KEY AUTOINCREMENT,
	publisher_id_number TEXT NOT NULL UNIQUE,
	publisher_name TEXT NOT NULL,
	publisher_address TEXT,
	publisher_contact TEXT,
);

--書籍分類
CREATE TABLE IF NOT EXISTS BookClass(
	bookclass_id INTEGER PRIMARY KEY AUTOINCREMENT,
	bookclass_number TEXT NOT NULL UNIQUE,
	bookclass_name TEXT NOT NULL UNIQUE
);

--作者
CREATE TABLE IF NOT EXISTS Author(
	author_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
	author_name TEXT NOT NULL,
	author_address TEXT,
	author_contact TEXT,
);
----------------------------------------------------------------------------------------------------------------------------------------------------
--索引建立
--借閱主檔資料表索引
CREATE INDEX IF NOT EXISTS idx_borr_id ON BorrowRecords(borr_id); -- 建立索引以提高查詢效率
CREATE INDEX IF NOT EXISTS idx_user_id ON BorrowRecords(user_id); -- 使用者ID索引
CREATE INDEX IF NOT EXISTS idx_bookinfo_id ON BorrowRecords(bookinfo_id); -- 書籍ID索引
CREATE INDEX IF NOT EXISTS idx_borr_status ON BorrowRecords(borr_status); -- 借閱狀態ID索引
CREATE INDEX IF NOT EXISTS idx_employee_id ON BorrowRecords(employee_id); -- 僱員ID索引
CREATE INDEX IF NOT EXISTS idx_borr_start ON BorrowRecords(borr_start); -- 借閱開始日期索引
CREATE INDEX IF NOT EXISTS idx_borr_end ON BorrowRecords(borr_end); -- 借閱結束日期索引
--使用者資料表索引
CREATE UNIQUE INDEX IF NOT EXISTS idx_user_id_number ON User(user_id_number); -- 確保 user_id_number 唯一性
CREATE INDEX IF NOT EXISTS idx_user_name ON User(user_name); -- 建立索引以提高查詢效率
CREATE FOREIGN KEY (user_id) REFERENCES BorrowRecords(user_id); -- 外鍵約束，確保使用者ID存在於借閱主檔資料表中，使用者資料表OK
--僱員職級表索引
CREATE UNIQUE INDEX IF NOT EXISTS idx_employeegrade_title ON EmployeeGrade(employeegrade_title); -- 確保 employeegrade_title 唯一性
CREATE INDEX IF NOT EXISTS idx_employeegrade_leavel ON EmployeeGrade(employeegrade_leavel); -- 建立索引以提高查詢效率
-- 書籍資訊索引
CREATE INDEX IF NOT EXISTS idx_bookinfo_title ON BookInfo(bookinfo_title);
CREATE INDEX IF NOT EXISTS idx_bookinfo_ISBN ON BookInfo(bookinfo_ISBN);
CREATE INDEX IF NOT EXISTS idx_bookinfo_publication ON BookInfo(bookinfo_publication);
-- 書籍分類索引
CREATE INDEX IF NOT EXISTS idx_bookclass_name ON BookClass(bookclass_name);
CREATE INDEX IF NOT EXISTS idx_bookclass_number ON BookClass(bookclass_number);
-- 書籍入庫紀錄索引
CREATE INDEX IF NOT EXISTS idx_books_entry ON Books(books_entry);
CREATE INDEX IF NOT EXISTS idx_books_current_time ON Books(books_current_time);
CREATE INDEX IF NOT EXISTS idx_books_status ON Books(books_status);
-- 書籍借閱紀錄索引
CREATE INDEX IF NOT EXISTS idx_borr_start ON BorrowRecords(borr_start);
CREATE INDEX IF NOT EXISTS idx_borr_end ON BorrowRecords(borr_end);
CREATE INDEX IF NOT EXISTS idx_borr_Qty ON BorrowRecords(borr_Qty);
-- 使用者索引
CREATE INDEX IF NOT EXISTS idx_user_name ON User(user_name);
CREATE INDEX IF NOT EXISTS idx_user_id_number ON User(user_id_number);

----------------------------------------------------------------------------------------------------------------------------------------------------
-- 借閱主檔資料表OK
INSERT INTO BorrowRecords(user_id, bookinfo_id, borr_status, borr_start, borr_end, borr_Qty, employee_id) VALUES
(1, 1, 1, '2023-01-01', '2023-01-15', 1, 1),
(2, 2, 1, '2023-01-02', '2023-01-16', 1, 2),
(3, 3, 1, '2023-01-03', '2023-01-17', 1, 3),
(4, 4, 1, '2023-01-04', '2023-01-18', 1, 4),
(5, 5, 1, '2023-01-05', '2023-01-19', 1, 5),
(1, 6, 1, '2023-01-06', '2023-01-20', 1, 1),
(2, 7, 1, '2023-01-07', '2023-01-21', 1, 2),
(3, 8, 1, '2023-01-08', '2023-01-22', 1, 3),
(4, 9, 1, '2023-01-09', '2023-01-23', 1, 4),
(5, 10, 1, '2023-01-10', '2023-01-24', 1, 5),
(1, 11, 1, '2023-01-11', '2023-01-25', 1, 1),
(2, 12, 1, '2023-01-12', '2023-01-26', 1, 2),
(3, 13, 1, '2023-01-13', '2023-01-27', 1, 3),
(4, 14, 1, '2023-01-14', '2023-01-28', 1, 4),
(5, 15, 1, '2023-01-15', '2023-01-29', 1, 5);
----------------------------------------------------------------------------------------------------------------------------------------------------
--使用者OK
INSERT INTO User(user_id_number, user_name, user_gender, user_brithday, user_phone, user_email, user_address, user_current_time, user_status) VALUES
('A123456789', 'Alice Chen', 0, '1995-07-15', '0911222333', 'alice.chen@example.com', '123 Cherry Lane', '2023-01-01 10:00:00', 1),
('B987654321', 'Bob Wang', 1, '1988-03-22', '0922334455', 'bob.wang@example.com', '456 Maple Street', '2023-01-02 11:00:00', 1),
('C567890123', 'Cathy Lin', 0, '2000-12-05', '0933445566', 'cathy.lin@example.com', '789 Elm Avenue', '2023-01-03 12:00:00', 1),
('D135792468', 'David Lee', 1, '1992-08-30', '0944556677', 'david.lee@example.com', '321 Pine Road', '2023-01-04 13:00:00', 1),
('E246813579', 'Emma Wu', 0, '1997-01-10', '0955667788', 'emma.wu@example.com', '987 Oak Lane', '2023-01-05 14:00:00', 1);

----------------------------------------------------------------------------------------------------------------------------------------------------
--僱員OK
INSERT INTO Employee(employeegrade_id, employee_id_number, employee_password, employee_name, employee_gender, employee_brithday, employee_contact, employee_address, employee_status) VALUES
(1, 'E123456789', 'password123', 'John Doe', 1, '1985-06-15', '0911222333', '456 Maple Street', 1),
(2, 'E987654321', 'securepass', 'Jane Smith', 0, '1990-03-22', '0922334455', '789 Elm Avenue', 1),
(3, 'E567890123', 'mypassword', 'Alice Brown', 0, '1978-12-05', '0933445566', '123 Oak Lane', 1),
(4, 'E135792468', 'adminpass', 'Bob White', 1, '1980-08-30', '0944556677', '321 Pine Road', 1),
(5, 'A123456789', 'a640506', 'seamhsu', 1, '1975-01-10', '0955667788', '台北市辛亥路四段', 1);
----------------------------------------------------------------------------------------------------------------------------------------------------
--僱員職位職級OK
INSERT INTO EmployeeGrade(employeegrade_title, employeegrade_leavel, emplayeegrade_salary, emplayeegrade_trendy) VALUES
('兼職', 0, 26000, 196),
('組長', 1, 30000, 220),
('科長', 2, 35000, 250);
----------------------------------------------------------------------------------------------------------------------------------------------------

--出勤紀錄OK
INSERT INTO Attendance(employee_id,attendance_date,attendance_time,attendance_status,attendance_desc) VALUES
(1,'2023/01/01','08:00:00','上班',''),
(1,'2023/01/01','17:00:00','下班',''),
(2,'2023/01/02','08:00:00','上班',''),
(2,'2023/01/02','17:00:00','下班',''),
(3,'2023/01/03','08:00:00','上班',''),
(3,'2023/01/03','17:00:00','下班',''),
(4,'2023/01/04','08:00:00','上班',''),
(4,'2023/01/04','17:00:00','下班',''),
(5,'2023/01/05','08:00:00','上班',''),
(5,'2023/01/05','17:00:00','下班',''),
(1,'2023/01/06','08:00:00','上班',''),
(1,'2023/01/06','17:00:00','下班',''),
(2,'2023/01/07','08:00:00','上班',''),
(2,'2023/01/07','17:00:00','下班',''),
(3,'2023/01/08','08:00:00','上班',''),
(3,'2023/01/08','17:00:00','下班',''),
(4,'2023/01/09','08:00:00','上班',''),
(4,'2023/01/09','17:00:00','下班',''),
(5,'2023/01/10','08:00:00','上班',''),
(5,'2023/01/10','17:00:00','下班','');
----------------------------------------------------------------------------------------------------------------------------------------------------
--借閱狀態ID
INSERT INTO BorrowStatus(borr_status_name,borr_status_desc,penalty_id) VALUES
('借閱中','使用者正在借閱書籍',1),
('已歸還','使用者已經歸還書籍',1),
('逾期未還','使用者逾期未還書籍',2),
('損壞','使用者損壞書籍',3),
('遺失','使用者遺失書籍',4);
----------------------------------------------------------------------------------------------------------------------------------------------------
--罰則OK
INSERT INTO Penalty(penalty_name,penalty_amount) VALUES
('正常歸還','0'),
('逾期罰款','50'),
('損壞罰款','200'),
('遺失罰款','500');
----------------------------------------------------------------------------------------------------------------------------------------------------
--書籍主檔OK
INSERT INTO Books(bookinfo_id,books_entry,books_current_time,books_status) VALUES
(1,1,'2023-01-01 10:00:00',1),
(2,1,'2023-01-02 11:00:00',1),
(3,1,'2023-01-03 12:00:00',1),
(4,1,'2023-01-04 13:00:00',1),
(5,1,'2023-01-05 14:00:00',1),
(6,1,'2023-01-06 15:00:00',1),
(7,1,'2023-01-07 16:00:00',1),
(8,1,'2023-01-08 17:00:00',1),
(9,1,'2023-01-09 18:00:00',1),
(10,1,'2023-01-10 19:00:00',1),
(11,1,'2023-01-11 20:00:00',1),
(12,1,'2023-01-12 21:00:00',1),
(13,1,'2023-01-13 22:00:00',1),
(14,1,'2023-01-14 23:00:00',1),
(15,1,'2023-01-15 24:00:00',1);
----------------------------------------------------------------------------------------------------------------------------------------------------
--書籍資料 OK
INSERT INTO BookInfo(bookinfo_ISBN,bookinfo_title,publisher_id,author_id,bookclass_id,bookinfo_publication) VALUES
('978-3-16-148410-0','book1',1,1,1,'2023-01-01'),
('978-3-16-148410-1','book2',2,2,2,'2023-01-02'),
('978-3-16-148410-2','book3',3,3,3,'2023-01-03'),
('978-3-16-148410-3','book4',4,4,4,'2023-01-04'),
('978-3-16-148410-4','book5',5,5,5,'2023-01-05'),
('978-3-16-148410-5','book6',1,2,3,'2023-01-06'),
('978-3-16-148410-6','book7',2,3,4,'2023-01-07'),
('978-3-16-148410-7','book8',3,4,5,'2023-01-08'),
('978-3-16-148410-8','book9',4,5,1,'2023-01-09'),
('978-3-16-148410-9','book10',5,1,2,'2023-01-10');
----------------------------------------------------------------------------------------------------------------------------------------------------
--書籍分類OK
INSERT INTO BookClass(bookclass_number,bookclass_name) VALUES
('A123','小說'),
('B456','漫畫'),
('C789','雜誌'),
('D012','報紙'),
('E345','學術期刊'),
('F678','參考書'),
('G901','教科書'),
('H234','工具書'),
('I567','電子書');
----------------------------------------------------------------------------------------------------------------------------------------------------
--出版社OK
INSERT INTO Publisher(publisher_id_number,publisher_name,publisher_address,publisher_contact) VALUES
('A123456789','台灣商務印書館','台北市信義區金山南路二段15號3樓','02-8856-2431'),
('B987654321','台灣學術出版社','台北市文山區辛亥路二段15號3樓','02-2256-4431'),
('C567890123','台灣經濟出版社','台北市信義區金山南路二段15號3樓','02-8856-2431'),
('D135792468','台灣文化出版社','台北市信義區金山南路二段15號3樓','02-8856-2431'),
('E246813579','台灣科技出版社','台北市信義區金山南路二段15號3樓','02-8856-2431');
----------------------------------------------------------------------------------------------------------------------------------------------------
--作者OK
INSERT INTO Author(author_name,author_address,author_contact) VALUES
('黃曉明','台北市信義區金山南路二段15號3樓','02-8856-2431'),
('花無缺','台北市文山區辛亥路二段15號3樓','02-2256-4431');
INSERT INTO Author(author_name,author_address,author_contact) VALUES
('黃曉明','台北市信義區金山南路二段15號3樓','02-8856-2431'),
('花無缺','台北市文山區辛亥路二段15號3樓','02-2256-4431'),
('小王子','台北市信義區金山南路二段15號3樓','02-8856-2431'),
('小美','台北市信義區金山南路二段15號3樓','02-8856-2431'),
('小明','台北市信義區金山南路二段15號3樓','02-8856-2431'),
('小華','台北市信義區金山南路二段15號3樓','02-8856-2431'),
('小美','台北市信義區金山南路二段15號3樓','02-8856-2431'),
('小王子','台北市信義區金山南路二段15號3樓','02-8856-2431');
-------------------------------------------------------------------------------

-- 2. 建立觸發器（Trigger）
-- 觸發器：當借閱狀態為逾期未還時，更新書籍狀態為逾期
CREATE TRIGGER IF NOT EXISTS update_books_status
AFTER UPDATE ON BorrowRecords
FOR EACH ROW
BEGIN
	UPDATE Books
	SET books_status = 0
	WHERE books_id = NEW.books_id AND NEW.borr_status = 3;
END;
-- 觸發器：當借閱狀態為已歸還時，更新書籍狀態為正常
CREATE TRIGGER IF NOT EXISTS update_books_status_return
AFTER UPDATE ON BorrowRecords
FOR EACH ROW
BEGIN
	UPDATE Books
	SET books_status = 1
	WHERE books_id = NEW.books_id AND NEW.borr_status = 2;
END;
-- 觸發器：當書籍入庫時，更新書籍狀態為正常
CREATE TRIGGER IF NOT EXISTS update_books_status_entry
AFTER INSERT ON Books
FOR EACH ROW
BEGIN
	UPDATE Books
	SET books_status = 1
	WHERE books_id = NEW.books_id;
END;
-- 觸發器：當書籍入庫數量為0時，更新書籍狀態為停權
CREATE TRIGGER IF NOT EXISTS update_books_status_zero
AFTER UPDATE ON Books
FOR EACH ROW
BEGIN
	UPDATE Books
	SET books_status = 0
	WHERE books_id = NEW.books_id AND NEW.books_entry = 0;
END;
-- 觸發器：當書籍入庫數量大於0時，更新書籍狀態為正常
CREATE TRIGGER IF NOT EXISTS update_books_status_greater
AFTER UPDATE ON Books
FOR EACH ROW
BEGIN
	UPDATE Books
	SET books_status = 1
	WHERE books_id = NEW.books_id AND NEW.books_entry > 0;
END;
-- 觸發器：當書籍入庫數量小於0時，更新書籍狀態為停權
CREATE TRIGGER IF NOT EXISTS update_books_status_less
AFTER UPDATE ON Books
FOR EACH ROW
BEGIN
	UPDATE Books
	SET books_status = 0
	WHERE books_id = NEW.books_id AND NEW.books_entry < 0;
END;
-------------------------------------------------------------------------------
-- 3. 建立檢視表（View）
-- 檢視表：借閱紀錄檢視表
CREATE VIEW IF NOT EXISTS BorrowRecordsView AS
SELECT
	borr.borr_id AS 借閱紀錄編號,
	u.user_name AS 借閱者名稱,
	b.bookinfo_title AS 書籍名稱,
	borr.borr_start AS 借閱開始日期,
	borr.borr_end AS 借閱結束日期,	
	borr.borr_Qty AS 借閱數量,
	bs.borr_status_name AS 借閱狀態,
	e.employee_name AS 僱員名稱
FROM
	BorrowRecords borr
JOIN User u ON borr.user_id = u.user_id
JOIN BookInfo b ON borr.bookinfo_id = b.bookinfo_id
JOIN BorrowStatus bs ON borr.borr_status = bs.borr_status_id
JOIN Employee e ON borr.employee_id = e.employee_id
WHERE
	borr.borr_status = 1; -- 只顯示借閱中的紀錄
-- 檢視表：書籍資訊檢視表
CREATE VIEW IF NOT EXISTS BookInfoView AS
SELECT
	bi.bookinfo_id AS 書籍編號,
	bi.bookinfo_ISBN AS 書籍ISBN碼,
	bi.bookinfo_title AS 書名,
	p.publisher_name AS 出版商名稱,
	a.author_name AS 作者姓名,
	bc.bookclass_name AS 書本類別,
	bi.bookinfo_publication AS 書本出版日期
FROM
	BookInfo bi
JOIN Publisher p ON bi.publisher_id = p.publisher_id
JOIN Author a ON bi.author_id = a.author_id
JOIN BookClass bc ON bi.bookclass_id = bc.bookclass_id;
-- 檢視表：書籍借閱紀錄檢視表
CREATE VIEW IF NOT EXISTS BookBorrowRecordsView AS
SELECT
	borr.borr_id AS 借閱紀錄編號,
	bi.bookinfo_title AS 書籍名稱,
	u.user_name AS 借閱者名稱,
	borr.borr_start AS 借閱開始日期,
	borr.borr_end AS 借閱結束日期,
	borr.borr_Qty AS 借閱數量,
	bs.borr_status_name AS 借閱狀態,
	e.employee_name AS 僱員名稱
FROM
	BorrowRecords borr
JOIN User u ON borr.user_id = u.user_id
JOIN BookInfo bi ON borr.bookinfo_id = bi.bookinfo_id
JOIN BorrowStatus bs ON borr.borr_status = bs.borr_status_id
JOIN Employee e ON borr.employee_id = e.employee_id
WHERE
	borr.borr_status = 1; -- 只顯示借閱中的紀錄
-- 檢視表：書籍入庫紀錄檢視表
CREATE VIEW IF NOT EXISTS BookEntryRecordsView AS
SELECT
	bi.bookinfo_id AS 書籍編號,
	bi.bookinfo_ISBN AS 書籍ISBN碼,
	bi.bookinfo_title AS 書名,
	bi.bookinfo_publication AS 書本出版日期,
	b.books_entry AS 入庫數量,
	b.books_current_time AS 入庫時間,
	b.books_status AS 書籍狀態
FROM
	Books b
JOIN BookInfo bi ON b.bookinfo_id = bi.bookinfo_id
WHERE
	b.books_status = 1; -- 只顯示正常狀態的書籍
-- 統計檢視表：書籍借出與在庫書籍統計
CREATE VIEW IF NOT EXISTS BookStatisticsView AS
SELECT
	bi.bookinfo_id AS 書籍編號,
	bi.bookinfo_title AS 書名,
	COUNT(borr.borr_id) AS 借閱次數,
	SUM(b.books_entry) AS 在庫數量
FROM
	BookInfo bi
LEFT JOIN BorrowRecords borr ON bi.bookinfo_id = borr.bookinfo_id
LEFT JOIN Books b ON bi.bookinfo_id = b.bookinfo_id
GROUP BY
	bi.bookinfo_id,
	bi.bookinfo_title;
-------------------------------------------------------------------------------
-- 4. 建立事務（Transaction）
BEGIN TRANSACTION;
-- 事務：借閱書籍
INSERT INTO BorrowRecords(user_id, bookinfo_id, borr_status, borr_start, borr_end, borr_Qty, employee_id)
VALUES
(1, 1, 1, '2023-01-01', '2023-01-15', 1, 1);
-- 事務：歸還書籍
-------------------------------------------------------------------------------
