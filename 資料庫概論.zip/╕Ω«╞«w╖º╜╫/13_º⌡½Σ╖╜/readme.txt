
任務簡述：
此專案建立一個簡單的圖書館資料庫，儲存書籍資料與借閱記錄，並提供基本的借閱次數查詢功能。

資料模型與正規化說明：
資料庫中將「書籍」與「借閱紀錄」分成兩張表格：Books 與 BorrowRecords。
- Books 表包含書名、作者與 ISBN，ISBN 設為唯一值避免重複。
- BorrowRecords 表記錄每一次借閱的日期與對應的書籍 ID，透過 BookID 做關聯。
這樣的設計符合第一與第二正規化，避免冗餘資料並提升查詢效率。

執行步驟：
1. 使用 SQLite 工具（如 DB Browser for SQLite）開啟 LibraryDB_Setup.sql 並執行。
2. 插入初始資料後，執行 BorrowCount_Result.txt 中的 SQL 指令即可查詢各書籍的借閱次數。
