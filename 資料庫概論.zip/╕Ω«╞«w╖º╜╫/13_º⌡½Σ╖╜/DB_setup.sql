-- 建立資料表：Books 與 BorrowRecords
-- 一個書籍表、一個借閱紀錄表

-- 1. 建立 Books 表格
CREATE TABLE Books (
    BookID INTEGER PRIMARY KEY AUTOINCREMENT,
    Title TEXT NOT NULL,
    Author TEXT NOT NULL,
    ISBN TEXT UNIQUE NOT NULL
);

-- 2. 建立 BorrowRecords 表格
CREATE TABLE BorrowRecords (
    RecordID INTEGER PRIMARY KEY AUTOINCREMENT,
    BookID INTEGER NOT NULL,
    BorrowDate DATE NOT NULL,
    FOREIGN KEY (BookID) REFERENCES Books(BookID)
);

-- 插入書籍資料
INSERT INTO Books (Title, Author, ISBN) VALUES
('世界上最透明的故事', '杉井光', '9789573342076'),
('你願意，人生就會值得：蔡康永的情商課3', '蔡康永', '9789861366968'),
('我可能錯了：森林智者的最後一堂人生課', 'Björn Natthiko Lindeblad, Caroline Bankler, Navid Modiri', '9789861344454'),
('被討厭的勇氣：自我啟發之父「阿德勒」的教導', '岸見一郎, 古賀史健', '9789861371955'),
('進烤箱的好日子', '李佳穎', '9789869202176');

-- 模擬借閱紀錄資料（假設借出 3 筆書）
INSERT INTO BorrowRecords (BookID, BorrowDate) VALUES
(1, '2025-04-01'),
(2, '2025-04-02'),
(1, '2025-04-10');

-- 查詢各書籍的借閱次數
SELECT b.Title, COUNT(r.RecordID) AS BorrowCount
FROM Books b
LEFT JOIN BorrowRecords r ON b.BookID = r.BookID
GROUP BY b.BookID
ORDER BY BorrowCount DESC;

CREATE TABLE Members (
    member_id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE,
    phone TEXT,
    joindate DATE DEFAULT (date('now'))
);


INSERT INTO Members (Name, NationalID, MemberID, Email, Phone)
VALUES
('王小明', 'A123456789', 'M001', 'xiaoming@example.com', '0912345678'),
('陳美麗', 'B234567890', 'M002', 'meili@example.com', '0922333444'),
('李志強', 'C345678901', 'M003', 'zhichang@example.com', '0933222111'),
('張雅婷', 'D456789012', 'M004', 'yating@example.com', '0955667788'),
('林建宏', 'E567890123', 'M005', 'jianhong@example.com', '0966778899');
