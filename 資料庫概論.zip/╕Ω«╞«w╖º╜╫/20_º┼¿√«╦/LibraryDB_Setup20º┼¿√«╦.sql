--建立表格
CREATE TABLE BOOK (
    book_id INTEGER PRIMARY KEY,
    title TEXT NOT NULL,
    author TEXT,
    publisher TEXT,
    year INTEGER,
    total_copies INTEGER,
    available_copies INTEGER
);

CREATE TABLE MEMBER (
    member_id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    phone TEXT,
    email TEXT
);

CREATE TABLE BORROW (
    borrow_id INTEGER PRIMARY KEY,
    book_id INTEGER,
    member_id INTEGER,
    borrow_date TEXT,
    return_date TEXT,
    FOREIGN KEY(book_id) REFERENCES BOOK(book_id),
    FOREIGN KEY(member_id) REFERENCES MEMBER(member_id)
);

--插入書籍資料
INSERT INTO BOOK VALUES
(1, 'Python入門', '王大明', 'ABC出版社', 2020, 5, 3),
(2, '資料庫系統概論', '李小英', 'XYZ出版社', 2018, 3, 2),
(3, '統計學', '林小美', 'EFG出版社', 2019, 10, 3),
(4, 'POWER BI', '劉小秀', 'IU出版社', 2024, 6, 6),
(5, '人工智慧導論', '陳建宏', '未來出版社', 2022, 4, 4);
INSERT INTO BOOK VALUES
(6, '資料結構', '吳明志', '程式出版社', 2019, 5, 5),
(7, '演算法分析', '蔡宗賢', '計算出版社', 2020, 3, 2),
(8, '區塊鏈技術', '張皓宇', '科技島出版社', 2021, 2, 2),
(9, 'Linux 系統管理', '朱嘉明', '開源出版社', 2017, 4, 3),
(10, '前端開發實戰', '劉思妤', 'Web出版社', 2022, 6, 6);

--插入會員資料
INSERT INTO MEMBER VALUES
(1, '張三', '0912345678', 'zhang@example.com'),
(2, '李四', '0922333444', 'li@example.com'),
(3, '陳二', '0933445544', 'cw@example.com'),
(4, '林六', '0911225544', 'ls@example.com'),
(5, '王五', '0933222111', 'wang@example.com');
INSERT INTO MEMBER VALUES
(6, '吳小強', '0922111555', 'wu@example.com'),
(7, '黃建宏', '0977888999', 'huang@example.com'),
(8, '周依婷', '0955666777', 'zhou@example.com'),
(9, '鄭宜君', '0966888999', 'cheng@example.com'),
(10, '曾浩宇', '0933555111', 'tseng@example.com');

--插入借閱記錄
INSERT INTO BORROW (book_id, member_id, borrow_date, return_date) VALUES
(1, 1, '2025-04-01', '2025-04-10'),
(2, 2, '2025-04-03', '2025-04-12'),
(1, 2, '2025-04-05', NULL);


--查詢某會員的借閱記錄
SELECT M.name, B.title, R.borrow_date, R.return_date
FROM BORROW R
JOIN MEMBER M ON R.member_id = M.member_id
JOIN BOOK B ON R.book_id = B.book_id
WHERE M.name = '李四';

-- 模擬還書狀況
UPDATE BORROW SET return_date = '2025-04-11' WHERE borrow_id = 3;

-- 更新庫存數量
UPDATE BOOK SET available_copies = available_copies + 1 WHERE book_id = 1;

-- 1. 查詢所有書籍資訊
SELECT * FROM BOOK;

-- 2. 查詢目前可借閱的書籍
SELECT title, author, available_copies
FROM BOOK
WHERE available_copies > 0;

-- 3. 查詢會員借閱紀錄（以會員姓名為條件）
SELECT M.name, B.title, R.borrow_date, R.return_date
FROM BORROW R
JOIN MEMBER M ON R.member_id = M.member_id
JOIN BOOK B ON R.book_id = B.book_id
WHERE M.name = '李四';

-- 4. 查詢尚未歸還的書籍
SELECT M.name AS 借閱者, B.title AS 書名, R.borrow_date AS 借出日期
FROM BORROW R
JOIN MEMBER M ON R.member_id = M.member_id
JOIN BOOK B ON R.book_id = B.book_id
WHERE R.return_date IS NULL;

-- 5. 統計每本書被借出幾次
SELECT B.title, COUNT(*) AS borrow_count
FROM BORROW R
JOIN BOOK B ON R.book_id = B.book_id
GROUP BY B.book_id;

-- 6. 查詢特定時間區間內的借閱紀錄
SELECT M.name, B.title, R.borrow_date
FROM BORROW R
JOIN MEMBER M ON R.member_id = M.member_id
JOIN BOOK B ON R.book_id = B.book_id
WHERE R.borrow_date BETWEEN '2025-04-01' AND '2025-04-05';

-- 7. 查詢某書籍的目前可借數量
SELECT title, available_copies
FROM BOOK
WHERE title = 'Python入門';




